#pragma once
#include <memory>

// �ӿڿ�ѡ
class IMap {
public:
	virtual ~IMap( ) = default;
	virtual void show( ) const = 0;
};
class Map :public IMap {
public:
	virtual ~Map( ) = default;
	virtual void show( ) const = 0;
};

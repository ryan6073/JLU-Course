#pragma once
#include <memory>

/**
* IMenu�ӿ�(��ѡ)
*/
class IMenu {
public:
	virtual ~IMenu( ) = default;
	virtual bool process( ) = 0;
};

class Menu :public IMenu {
public:
	virtual ~Menu( ) = default;
	virtual bool process( ) = 0;
};

/**
* ����̨�˵�����
**/
class ConsoleMenu :public Menu {
public:
	virtual bool process( ) {
		display( );
		int choice = selectMenuItem( );
		return doAction( choice );
	}
protected:
	virtual void display( ) const = 0;
	virtual int  selectMenuItem( ) const;
	virtual bool doAction( int choice ) = 0;
};

/**
* ���˵�
**/
class MainMenu : public ConsoleMenu {
protected:
	virtual void display( ) const  override;
	virtual bool doAction( int choice ) override;
};

/**
* ����Ϸ�˵�
**/
class NewMenu : public ConsoleMenu {
protected:
	virtual void display( ) const  override;
	virtual bool doAction( int choice ) override;
};
/**
* ����˵�
**/
class LoadMenu : public ConsoleMenu {
protected:
	virtual void display( ) const  override;
	virtual bool doAction( int choice ) override;
};

/**
* ѡ��˵�
**/
class OptionMenu : public ConsoleMenu {
protected:
	virtual void display( ) const  override;
	virtual bool doAction( int choice ) override;
};

/**
* ��Ϸ�˵�
**/
class PlayMenu :public ConsoleMenu {
protected:
	virtual void display( ) const override;
	virtual bool doAction( int choice ) override;
};

/**
* �浵�˵�
**/
class SaveMenu :public ConsoleMenu {
protected:
	virtual void display( ) const override;
	virtual bool doAction( int choice ) override;
};

/**
* ��ͣ�˵�
**/
class PauseMenu :public ConsoleMenu {
protected:
	virtual void display( ) const override;
	virtual bool doAction( int choice ) override;
};

/**
 * �������ز˵�
 **/
class AnimateMenu :public ConsoleMenu {
protected:
	virtual void display( ) const override;
	virtual bool doAction( int choice ) override;
};

/**
* ���ֿ��ز˵�
**/
class MusicMenu :public ConsoleMenu {
protected:
	virtual void display( ) const override;
	virtual bool doAction( int choice ) override;
};

/**
* ��������˵�
**/
class PlayerCountMenu :public ConsoleMenu {
protected:
	virtual void display( ) const override;
	virtual bool doAction( int choice ) override;
};

/**
* �Ѷȵȼ��˵�
**/
class DifficultyMenu :public ConsoleMenu {
protected:
	virtual void display( ) const override;
	virtual bool doAction( int choice ) override;
};


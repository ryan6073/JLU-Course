#include "App.h"
#include "Menu.h"
#include "MenuMgr.h"

void App::init( ) {
}

void App::run( ) {
	bool running = true;
	while ( running ) {
		Menu * pMenu = menuMgr.activedMenu( );
		running = pMenu->process( );
	}
}

void App::term( ) {
}

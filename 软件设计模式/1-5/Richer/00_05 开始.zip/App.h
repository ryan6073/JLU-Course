#pragma once

class App {
public:
	void init( );
	void run( );
	void term( );
};


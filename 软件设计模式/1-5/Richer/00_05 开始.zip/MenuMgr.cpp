#pragma once
#include <memory>
#include <vector>

#include "Menu.h"
#include "MenuMgr.h"
#include "MenuType.h"

//ʵ����ȫ�ֶ���MenuMgr
MenuMgr  menuMgr;

MenuMgr::MenuMgr( ) {
	mVctMenus.push_back( std::shared_ptr<Menu>( new MainMenu( ) ) );
	mVctMenus.push_back( std::shared_ptr<Menu>( new NewMenu( ) ) );
	mVctMenus.push_back( std::shared_ptr<Menu>( new LoadMenu( ) ) );
	mVctMenus.push_back( std::shared_ptr<Menu>( new OptionMenu( ) ) );
	mVctMenus.push_back( std::shared_ptr<Menu>( new PlayMenu( ) ) );
	mVctMenus.push_back( std::shared_ptr<Menu>( new SaveMenu( ) ) );
	mVctMenus.push_back( std::shared_ptr<Menu>( new PauseMenu( ) ) );
	mVctMenus.push_back( std::shared_ptr<Menu>( new AnimateMenu( ) ) );
	mVctMenus.push_back( std::shared_ptr<Menu>( new MusicMenu( ) ) );
	mVctMenus.push_back( std::shared_ptr<Menu>( new PlayerCountMenu( ) ) );
	mVctMenus.push_back( std::shared_ptr<Menu>( new DifficultyMenu( ) ) );

	setActivedMenu( MenuType::MAIN_MENU );
}

void MenuMgr::setActivedMenu( int menuType ) {
	mCurMenu = mVctMenus[ menuType ].get( );
}
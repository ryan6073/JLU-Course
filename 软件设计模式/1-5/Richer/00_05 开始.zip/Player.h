#pragma once

// �ӿڿ�ѡ
class IPlayer {
public:
	virtual ~IPlayer( ) = default;
	virtual void advance( ) = 0;
};

class Player :public IPlayer {
public:
	virtual ~Player( ) = default;
	virtual void advance( ) = 0;
};

#include "QChatRoom.h"

QChatRoom::QChatRoom(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}

QChatRoom::~QChatRoom()
{

}
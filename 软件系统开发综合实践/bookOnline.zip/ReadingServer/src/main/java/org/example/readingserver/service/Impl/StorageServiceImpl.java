package org.example.readingserver.service.Impl;

import org.example.readingserver.service.IStorageService;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

@Service
public class StorageServiceImpl implements IStorageService {
    public Boolean save(MultipartFile file, String name, String path) {
        String filePath = path + name;
        File dest = new File(filePath);
        if(!dest.getParentFile().exists()) {
            dest.getParentFile().mkdirs();
        }

        try {
            FileCopyUtils.copy(file.getBytes(), dest);
        } catch (IOException e) {
            return false;
        }

        return true;
    }
}

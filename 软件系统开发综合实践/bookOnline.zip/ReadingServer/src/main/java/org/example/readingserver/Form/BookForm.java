package org.example.readingserver.Form;

import lombok.Data;

@Data
public class BookForm {
    private String bookname;
    private String img;
    private String booklink;
    private String uploader;
    private String uploaderid;
}

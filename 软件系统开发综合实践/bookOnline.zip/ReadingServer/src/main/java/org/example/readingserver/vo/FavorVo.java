package org.example.readingserver.vo;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class FavorVo {
    private BigDecimal ID;
    private BigDecimal userid;
    private BigDecimal bookid;
}

package org.example.readingserver.enums;

import lombok.Getter;

public enum ResultEnum {
    SUCCESS(0, "success"),
    ERROR_UNKNOWN(-1, "unknown exception"),
    ERROR_NOTFOUND(404, "not found"),
    ERROR_OPERATION_FAILED(500, "operation failed"),
    ERROR_PERMISSION_DENIED(403, "permission denied"),
    ERROR_USER_GROUP_NOT_NULL(1001, "user group not null"),
    ERROR_PASSWORD(1002, "password error");

    int code;
    @Getter
    String msg;

    ResultEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }
}

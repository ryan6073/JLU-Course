package org.example.readingserver.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.example.readingserver.pojo.Book;

public interface IBookService extends IService<Book> {
}

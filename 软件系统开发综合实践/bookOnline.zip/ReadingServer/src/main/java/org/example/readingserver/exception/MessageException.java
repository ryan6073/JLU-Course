package org.example.readingserver.exception;

import org.example.readingserver.enums.ResultEnum;

public class MessageException extends RuntimeException{
    private MessageException(String message) {
        super(message);
    }

    public static MessageException notFound() {
        return new MessageException(ResultEnum.ERROR_NOTFOUND.getMsg());
    }

    public static MessageException operationFailed() {
        return new MessageException(ResultEnum.ERROR_OPERATION_FAILED.getMsg());
    }

    public static MessageException unknownException() {
        return new MessageException(ResultEnum.ERROR_UNKNOWN.getMsg());
    }

    public static MessageException permissionDenied() {
        return new MessageException(ResultEnum.ERROR_PERMISSION_DENIED.getMsg());
    }

    public static MessageException userGroupNotNull() {
        return new MessageException(ResultEnum.ERROR_USER_GROUP_NOT_NULL.getMsg());
    }
}

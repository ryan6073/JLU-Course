package org.example.readingserver.service.Impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.example.readingserver.mapper.MessageMapper;
import org.example.readingserver.pojo.Message;
import org.example.readingserver.service.IMessageService;
import org.springframework.stereotype.Service;

@Service
public class MessageServiceImpl extends ServiceImpl<MessageMapper, Message> implements IMessageService {
}

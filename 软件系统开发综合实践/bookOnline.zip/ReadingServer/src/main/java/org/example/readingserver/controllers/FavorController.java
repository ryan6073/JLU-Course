package org.example.readingserver.controllers;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import lombok.extern.slf4j.Slf4j;
import org.example.readingserver.Form.FavorForm;
import org.example.readingserver.exception.FavorException;
import org.example.readingserver.exception.UserException;
import org.example.readingserver.pojo.Book;
import org.example.readingserver.pojo.Favor;
import org.example.readingserver.pojo.User;
import org.example.readingserver.service.IBookService;
import org.example.readingserver.service.IFavorService;
import org.example.readingserver.service.IUserService;
import org.example.readingserver.vo.FavorVo;
import org.example.readingserver.vo.Result;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@RestController
@Slf4j
@RequestMapping("/favor")
public class FavorController {

    @Autowired
    private IFavorService favorService;

    @Autowired
    private IUserService userService;

    @Autowired
    private IBookService bookService;

    @PostMapping("/add")
    public Result add(@RequestBody FavorForm favorForm) {
        Favor favor = new Favor();
        favor.setBookid(BigDecimal.valueOf(Integer.parseInt(favorForm.getBookid())));
        favor.setUserid(BigDecimal.valueOf(Integer.parseInt(favorForm.getUserid())));
        boolean flag = favorService.save(favor);
        if (!flag) {
            throw FavorException.operationFailed();
        }
        FavorVo favorVo = new FavorVo();
        BeanUtils.copyProperties(favor, favorVo);
        return Result.success(favorVo);
    }

    @DeleteMapping("/delete")
    public Result delete(@RequestBody FavorForm favorForm) {
        QueryWrapper<Favor> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("userid", favorForm.getUserid());
        queryWrapper.eq("bookid", favorForm.getBookid());
        boolean flag = favorService.remove(queryWrapper);
        if (!flag) {
            throw FavorException.operationFailed();
        }
        return Result.success();
    }

    @PostMapping("showFavor/{id}")
    public Result showFavor(@PathVariable int id) {
        User user = userService.getById(id);
        if(user == null) {
            throw UserException.notFound();
        }
        List<Book> bookList = new ArrayList<>();
        QueryWrapper<Favor> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("userid", user.getID());
        List<Favor> favorList = favorService.list(queryWrapper);
        for(Favor favor : favorList) {
            Book book = bookService.getById(favor.getBookid());
            bookList.add(book);
        }
        return Result.success(bookList);
    }

    @PostMapping("queryFavor/{userId}/{bookId}")
    public Result queryFavor(@PathVariable int userId, @PathVariable int bookId) {
        QueryWrapper<Favor> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("userid", userId);
        queryWrapper.eq("bookid", bookId);
        Favor favor = favorService.getOne(queryWrapper);
        if(favor == null) {
            return Result.success(false);
        }
        return Result.success(true);
    }
}

package org.example.readingserver.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;

@Data
@TableName("MESSAGETABLE")
public class Message {
    @TableId(value = "ID", type = IdType.AUTO)
    private BigDecimal ID;
    private String time;
    private String content;
    private String sender;
    private String receiver;
    private String isread;
    private String isdelsend;
    private String isdelrev;
    private String groupid;
}

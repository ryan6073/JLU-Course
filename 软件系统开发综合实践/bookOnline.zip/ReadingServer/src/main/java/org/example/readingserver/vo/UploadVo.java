package org.example.readingserver.vo;

import lombok.Data;

@Data
public class UploadVo {
    String accessUrl;
    String localUrl;
}

package org.example.readingserver.exception;

import org.example.readingserver.enums.ResultEnum;
import org.example.readingserver.vo.Result;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class FavorExceptionHandler {
    @ExceptionHandler(FavorException.class)
    public Result FavorExceptionHandler(FavorException e) {
        if(e.getMessage().endsWith(ResultEnum.ERROR_OPERATION_FAILED.getMsg()))
            return Result.fail(ResultEnum.ERROR_OPERATION_FAILED);
        return Result.fail();
    }

//    @ExceptionHandler(Exception.class)
//    public Result ExceptionHandler(Exception e) {
//        return Result.fail();
//    }
}

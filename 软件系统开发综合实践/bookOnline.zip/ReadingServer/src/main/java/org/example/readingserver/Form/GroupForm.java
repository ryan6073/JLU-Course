package org.example.readingserver.Form;

import lombok.Data;

@Data
public class GroupForm {
    private String groupid;
    private String managerid;
}

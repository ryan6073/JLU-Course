package org.example.readingserver.controllers;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import lombok.extern.slf4j.Slf4j;
import org.example.readingserver.Form.GroupForm;
import org.example.readingserver.Form.UserForm;
import org.example.readingserver.exception.UserException;
import org.example.readingserver.pojo.User;
import org.example.readingserver.service.IUserService;
import org.example.readingserver.vo.Result;
import org.example.readingserver.vo.UserVo;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
@RequestMapping("/user")
public class UserController {

    @Value("${upload.localPath}")
    private String localImgPath;

    @Autowired
    private IUserService userService;

    @PostMapping("/register")
    public Result register(@RequestBody User user) {
        log.info("user: {}", user);
        boolean flag = userService.save(user);
        if (!flag) {
            throw UserException.operationFailed();
        }
        UserVo userVo = new UserVo();
        BeanUtils.copyProperties(user, userVo);
        return Result.success(userVo);
    }

    @PostMapping("/login")
    public Result login(@RequestBody UserForm userForm) {
        String email = userForm.getEmail();
        String password = userForm.getPassword();
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("email", email);
        queryWrapper.eq("password", password);
        User user = userService.getOne(queryWrapper);
        if (user == null) {
            throw UserException.notFound();
        }
        UserVo userVo = new UserVo();
        BeanUtils.copyProperties(user, userVo);
        return Result.success(userVo);
    }

    @PostMapping("/edit/{id}")
    public Result edit(@RequestBody UserForm userForm, @PathVariable int id) {
        User user = userService.getById(id);
        if (user == null) {
            throw UserException.notFound();
        }

        if (userForm.getUsername() != null) {
            user.setUsername(userForm.getUsername());
        }
        if (userForm.getPassword() != null) {
            user.setPassword(userForm.getPassword());
        }
        if (userForm.getAvatar() != null) {
            user.setAvatar(userForm.getAvatar());
        }

        boolean flag = userService.updateById(user);
        if (!flag) {
            throw UserException.operationFailed();
        }

        UserVo userVo = new UserVo();
        BeanUtils.copyProperties(user, userVo);
        return Result.success(userVo);
    }

    @PostMapping("confirmPass/{id}")
    public Result confirmPass(@RequestBody UserForm userForm ,@PathVariable int id) {
        User user = userService.getById(id);
        if (user == null) {
            throw UserException.notFound();
        }
        if (!userForm.getPassword().equals(user.getPassword())) {
            throw UserException.passwordError();
        }
        return Result.success();
    }

    @PostMapping("/loginGroup")
    public Result loginGroup(@RequestBody GroupForm groupForm) {
        String manager = groupForm.getManagerid();
        String group = groupForm.getGroupid();
        User user = userService.getById(Integer.parseInt(manager));
        if(user == null) {
            throw UserException.notFound();
        }
        if(!user.getIsmanager().equals("1") || !user.getGroupid().equals(group)) {
            throw UserException.permissionDenied();
        }
        // 查询所有组员
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("groupid", group);
        return Result.success(userService.list(queryWrapper));
    }

    @PostMapping("/removeMember/{id}")
    public Result removeMember(@PathVariable int id) {
        User user = userService.getById(id);
        if (user == null) {
            throw UserException.notFound();
        }
        user.setGroupid("-1");
        boolean flag = userService.updateById(user);
        if (!flag) {
            throw UserException.operationFailed();
        }
        UserVo userVo = new UserVo();
        BeanUtils.copyProperties(user, userVo);
        return Result.success(userVo);
    }

    @PostMapping("/deleteAvatar/{id}")
    public Result deleteAvatar(@PathVariable int id) {
        User user = userService.getById(id);
        if (user == null) {
            throw UserException.notFound();
        }
        user.setAvatar(localImgPath + "default.jpg");
        boolean flag = userService.updateById(user);
        if (!flag) {
            throw UserException.operationFailed();
        }
        UserVo userVo = new UserVo();
        BeanUtils.copyProperties(user, userVo);
        return Result.success(userVo);
    }

    @PostMapping("/changeName/{id}")
    public Result changeName(@PathVariable int id) {
        User user = userService.getById(id);
        if (user == null) {
            throw UserException.notFound();
        }
        user.setUsername("用户" + id);
        boolean flag = userService.updateById(user);
        if (!flag) {
            throw UserException.operationFailed();
        }
        UserVo userVo = new UserVo();
        BeanUtils.copyProperties(user, userVo);
        return Result.success(userVo);
    }

    @PostMapping("/createGroup/{id}")
    public Result createGroup(@PathVariable int id) {
        User user = userService.getById(id);
        if (user == null) {
            throw UserException.notFound();
        }
        user.setGroupid(String.valueOf(id));
        user.setIsmanager("1");
        boolean flag = userService.updateById(user);
        if (!flag) {
            throw UserException.operationFailed();
        }
        UserVo userVo = new UserVo();
        BeanUtils.copyProperties(user, userVo);
        return Result.success(userVo);
    }

    @PostMapping("/quitGroup/{id}")
    public Result quitGroup(@PathVariable int id) {
        User user = userService.getById(id);
        if (user == null) {
            throw UserException.notFound();
        }
        user.setGroupid("-1");
        user.setIsmanager("0");
        boolean flag = userService.updateById(user);
        if (!flag) {
            throw UserException.operationFailed();
        }
        UserVo userVo = new UserVo();
        BeanUtils.copyProperties(user, userVo);
        return Result.success(userVo);
    }

    @PostMapping("deleteGroup/{id}")
    public Result deleteGroup(@PathVariable int id) {
        User user = userService.getById(id);
        if (user == null) {
            throw UserException.notFound();
        }
        if (!user.getIsmanager().equals("1")) {
            throw UserException.permissionDenied();
        }
        user.setIsmanager("0");
        boolean flag = userService.updateById(user);
        if (!flag) {
            throw UserException.operationFailed();
        }

        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("groupid", user.getGroupid());
        for(User u : userService.list(queryWrapper)) {
            u.setGroupid("-1");
            userService.updateById(u);
        }
        return Result.success();
    }
}

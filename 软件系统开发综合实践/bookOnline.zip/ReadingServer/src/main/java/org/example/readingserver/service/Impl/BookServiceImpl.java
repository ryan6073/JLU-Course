package org.example.readingserver.service.Impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.example.readingserver.mapper.BookMapper;
import org.example.readingserver.pojo.Book;
import org.example.readingserver.service.IBookService;
import org.springframework.stereotype.Service;

@Service
public class BookServiceImpl extends ServiceImpl<BookMapper, Book> implements IBookService {
}

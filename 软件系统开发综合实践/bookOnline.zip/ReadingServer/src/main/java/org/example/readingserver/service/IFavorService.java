package org.example.readingserver.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.example.readingserver.pojo.Favor;

public interface IFavorService extends IService<Favor> {
}

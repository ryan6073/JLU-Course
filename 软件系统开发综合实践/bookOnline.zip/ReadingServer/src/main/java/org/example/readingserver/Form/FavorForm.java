package org.example.readingserver.Form;

import lombok.Data;

@Data
public class FavorForm {
    private String userid;
    private String bookid;
}

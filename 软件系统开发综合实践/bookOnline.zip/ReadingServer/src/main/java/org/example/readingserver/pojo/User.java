package org.example.readingserver.pojo;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.math.BigDecimal;

@Data
@TableName("USERTABLE")
public class User {
    @TableId(value = "ID", type = IdType.AUTO)
    private BigDecimal ID;
    private String username;
    private String password;
    private String email;
    private String groupid;
    private String ismanager;
    private String avatar;
}

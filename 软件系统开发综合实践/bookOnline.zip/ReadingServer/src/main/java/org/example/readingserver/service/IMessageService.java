package org.example.readingserver.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.example.readingserver.pojo.Message;

public interface IMessageService extends IService<Message> {
}

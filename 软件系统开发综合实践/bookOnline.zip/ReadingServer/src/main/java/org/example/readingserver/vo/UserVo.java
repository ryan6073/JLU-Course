package org.example.readingserver.vo;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class UserVo {
    private BigDecimal ID;
    private String username;
    private String email;
    private String groupid;
    private String ismanager;
    private String avatar;
}

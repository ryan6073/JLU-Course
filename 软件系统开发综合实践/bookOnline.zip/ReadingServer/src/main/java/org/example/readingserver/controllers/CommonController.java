package org.example.readingserver.controllers;

import lombok.extern.slf4j.Slf4j;
import org.example.readingserver.exception.UserException;
import org.example.readingserver.pojo.User;
import org.example.readingserver.service.IStorageService;
import org.example.readingserver.service.IUserService;
import org.example.readingserver.vo.Result;
import org.example.readingserver.vo.UploadVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.util.Objects;

@RestController
@Slf4j
@RequestMapping("/")
public class CommonController {

    @Autowired
    private IStorageService storageService;

    @Autowired
    private IUserService userService;

    @Value("${upload.accessPath}")
    private String accessImgPath;

    @Value("${upload.localPath}")
    private String localImgPath;

    @Value("${book.accessPath}")
    private String accessBookPath;

    @Value("${book.localPath}")
    private String localBookPath;

    @PostMapping("uploadImg")
    public Result uploadImg(HttpServletRequest request, HttpServletResponse response) {
        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        MultipartFile file =  multipartRequest.getFile("file");
        if (file != null) {
            storageService.save(file, file.getOriginalFilename(), localImgPath);
        }
        UploadVo uploadVo = new UploadVo();
        uploadVo.setAccessUrl(accessImgPath + file.getOriginalFilename());
        uploadVo.setLocalUrl(localImgPath + file.getOriginalFilename());
        return Result.success(uploadVo);
    }

    @PostMapping("uploadPDF/{id}")
    public Result uploadPDF(HttpServletRequest request, HttpServletResponse response, @PathVariable Long id) {
        User user = userService.getById(id);
        if(user == null){
            throw UserException.notFound();
        }
        if(Objects.equals(user.getIsmanager(), "0")){
            throw UserException.permissionDenied();
        }

        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        MultipartFile file =  multipartRequest.getFile("file");
        if (file != null) {
            storageService.save(file, file.getOriginalFilename(), localBookPath);
        }
        UploadVo uploadVo = new UploadVo();
        uploadVo.setAccessUrl(accessBookPath + file.getOriginalFilename());
        uploadVo.setLocalUrl(localBookPath + file.getOriginalFilename());
        return Result.success(uploadVo);
    }
}

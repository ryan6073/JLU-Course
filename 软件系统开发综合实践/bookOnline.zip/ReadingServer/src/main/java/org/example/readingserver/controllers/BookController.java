package org.example.readingserver.controllers;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.extern.slf4j.Slf4j;
import org.example.readingserver.Form.BookForm;
import org.example.readingserver.exception.BookException;
import org.example.readingserver.exception.UserException;
import org.example.readingserver.pojo.Book;
import org.example.readingserver.pojo.Message;
import org.example.readingserver.pojo.User;
import org.example.readingserver.service.IBookService;
import org.example.readingserver.service.IUserService;
import org.example.readingserver.vo.BookVo;
import org.example.readingserver.vo.MessageVo;
import org.example.readingserver.vo.Result;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@RestController
@Slf4j
@RequestMapping("/book")
public class BookController {

    @Autowired
    private IBookService bookService;

    @Autowired
    private IUserService userService;

    @GetMapping("/list")
    public Result list(@RequestParam(defaultValue = "1") int page, @RequestParam(defaultValue = "6") int size) {
        log.info("page: {}, size: {}", page, size);
        Page<Book> bookPage = new Page<>(page, size);
        IPage<Book> pageResult = bookService.page(bookPage);

        List bookVoList = pageResult.getRecords().stream().map(book -> {
            BookVo bookVo = new BookVo();
            BeanUtils.copyProperties(book, bookVo);
            return bookVo;
        }).collect(Collectors.toList());

        pageResult.setRecords(bookVoList);

        return Result.success(pageResult);
    }

    @GetMapping("/detail/{id}")
    public Result detail(@PathVariable Long id) {
        log.info("id: {}", id);
        Book book = bookService.getById(id);
        if (book == null) {
            throw BookException.notFound();
        }
        BookVo bookVo = new BookVo();
        BeanUtils.copyProperties(book, bookVo);
        return Result.success(bookVo);
    }

    @PostMapping("/add")
    public Result add(@RequestBody BookForm bookForm) {
        Book book = new Book();
        BeanUtils.copyProperties(bookForm, book);
        boolean flag = bookService.save(book);

        if (!flag) {
            throw BookException.operationFailed();
        }

        BookVo bookVo = new BookVo();
        BeanUtils.copyProperties(book, bookVo);
        return Result.success(bookVo);
    }

    @PutMapping("/edit/{userId}/{bookId}")
    public Result edit(@RequestBody BookForm bookForm, @PathVariable int userId, @PathVariable int bookId) {
        User user = userService.getById(userId);
        if (user == null) {
            throw UserException.notFound();
        }
        if(Objects.equals(user.getIsmanager(), "0")){
            throw UserException.permissionDenied();
        }
        Book book = bookService.getById(bookId);
        BeanUtils.copyProperties(bookForm, book);
        boolean flag = bookService.updateById(book);
        if (!flag) {
            throw BookException.operationFailed();
        }

        BookVo bookVo = new BookVo();
        BeanUtils.copyProperties(book, bookVo);
        return Result.success(bookVo);
    }

    @DeleteMapping("/delete/{bookId}/{userId}")
    public Result delete(@PathVariable int bookId, @PathVariable int userId) {
        User user = userService.getById(userId);
        if (user == null) {
            throw UserException.notFound();
        }
        if (Objects.equals(user.getIsmanager(), "0")) {
            throw UserException.permissionDenied();
        }

        boolean flag = bookService.removeById(bookId);

        if (!flag) {
            throw BookException.operationFailed();
        }

        return Result.success();
    }

    @PostMapping("/read/{id}")
    public Result read(@PathVariable int id) {
        log.info("id: {}", id);
        Book book = bookService.getById(id);
        if (book == null) {
            throw BookException.notFound();
        }
        book.setHits(String.valueOf(Integer.parseInt(book.getHits()) + 1));
        boolean flag = bookService.updateById(book);
        if (!flag) {
            throw BookException.operationFailed();
        }
        return Result.success(book);
    }

    @PostMapping("/top3")
    public Result top3() {
        QueryWrapper<Book> queryWrapper = new QueryWrapper<>();
        queryWrapper.orderByDesc("HITS");
        List<Book> bookList = bookService.list(queryWrapper);
        List<Book> top3List = bookList.subList(0, 3);
        // 计算其余书的总点击数
        int otherHits = bookList.stream().skip(3).mapToInt(book -> Integer.parseInt(book.getHits())).sum();

        List<BookVo> bookVoList = top3List.stream().map(book -> {
            BookVo bookVo = new BookVo();
            BeanUtils.copyProperties(book, bookVo);
            bookVo.setOtherhits(String.valueOf(otherHits));
            return bookVo;
        }).collect(Collectors.toList());
        return Result.success(bookVoList);
    }

    @PostMapping("/search/{userid}")
    public Result search(@PathVariable String userid, @RequestParam(defaultValue = "1") int page,
                         @RequestParam(defaultValue = "6") int size) {
        User user = userService.getById(userid);
        if (user == null) {
            throw UserException.notFound();
        }

        Page<Book> bookPage = new Page<>(page, size);
        QueryWrapper<Book> queryWrapper = new QueryWrapper<>();

        queryWrapper.eq("uploaderid", userid);
        IPage<Book> bookResult = bookService.page(bookPage, queryWrapper);

        List bookVoList = bookResult.getRecords().stream()
                .map(book -> {
                    BookVo bookVo = new BookVo();
                    BeanUtils.copyProperties(book, bookVo);
                    return bookVo;
                }).collect(Collectors.toList());

        bookResult.setRecords(bookVoList);
        return Result.success(bookResult);
    }
}

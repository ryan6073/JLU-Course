package org.example.readingserver.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.example.readingserver.pojo.User;

public interface IUserService extends IService<User> {
    User getByEmail(String sender);
}

package org.example.readingserver.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.example.readingserver.pojo.Favor;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface FavorMapper extends BaseMapper<Favor>{
}

package org.example.readingserver;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("org.example.readingserver.mapper")
public class ReadingServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ReadingServerApplication.class, args);
    }

}

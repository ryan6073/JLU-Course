package org.example.readingserver.exception;

import org.example.readingserver.enums.ResultEnum;

public class BookException extends RuntimeException{
    private BookException(String message) {
        super(message);
    }

    public static BookException notFound() {
        return new BookException(ResultEnum.ERROR_NOTFOUND.getMsg());
    }

    public static BookException operationFailed() {
        return new BookException(ResultEnum.ERROR_OPERATION_FAILED.getMsg());
    }

    public static BookException unknownException() {
        return new BookException(ResultEnum.ERROR_UNKNOWN.getMsg());
    }
}

package org.example.readingserver.exception;

import org.example.readingserver.enums.ResultEnum;

public class UserException extends RuntimeException{
    private UserException(String message) {
        super(message);
    }

    public static UserException notFound() {
        return new UserException(ResultEnum.ERROR_NOTFOUND.getMsg());
    }

    public static UserException operationFailed() {
        return new UserException(ResultEnum.ERROR_OPERATION_FAILED.getMsg());
    }

    public static UserException unknownException() {
        return new UserException(ResultEnum.ERROR_UNKNOWN.getMsg());
    }

    public static UserException permissionDenied() {
        return new UserException(ResultEnum.ERROR_PERMISSION_DENIED.getMsg());
    }

    public static UserException passwordError() {
        return new UserException(ResultEnum.ERROR_PASSWORD.getMsg());
    }
}

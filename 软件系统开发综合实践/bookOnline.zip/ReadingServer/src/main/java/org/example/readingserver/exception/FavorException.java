package org.example.readingserver.exception;

import org.example.readingserver.enums.ResultEnum;

public class FavorException extends RuntimeException{
    private FavorException(String message) {
        super(message);
    }

    public static FavorException operationFailed() {
        return new FavorException(ResultEnum.ERROR_OPERATION_FAILED.getMsg());
    }

    public static FavorException unknownException() {
        return new FavorException(ResultEnum.ERROR_UNKNOWN.getMsg());
    }
}

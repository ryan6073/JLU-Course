package org.example.readingserver.vo;

import lombok.Data;

@Data
public class MessageVo {
    private String ID;
    private String time;
    private String content;
    private String sender;
    private String receiver;
    private String isread;
    private String isdelsend;
    private String isdelrev;
    private String groupid;
}

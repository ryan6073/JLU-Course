package org.example.readingserver.Form;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class UserForm {
    private String username;
    private String password;
    private String email;
    private String avatar;
}

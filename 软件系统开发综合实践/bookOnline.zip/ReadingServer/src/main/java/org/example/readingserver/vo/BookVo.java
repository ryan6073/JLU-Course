package org.example.readingserver.vo;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class BookVo {
    private BigDecimal ID;
    private String bookname;
    private String img;
    private String booklink;
    private String uploader;
    private String hits;
    private String otherhits;
    private String uploaderid;
}

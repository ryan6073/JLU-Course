package org.example.readingserver.service.Impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.example.readingserver.mapper.FavorMapper;
import org.example.readingserver.pojo.Favor;
import org.example.readingserver.service.IFavorService;
import org.springframework.stereotype.Service;

@Service
public class FavorServiceImpl extends ServiceImpl<FavorMapper, Favor> implements IFavorService {
}

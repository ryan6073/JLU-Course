package org.example.readingserver.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.math.BigDecimal;

@Data
@TableName("FAVORTABLE")
public class Favor {
    @TableId(value = "ID", type = IdType.AUTO)
    private BigDecimal ID;
    private BigDecimal userid;
    private BigDecimal bookid;
}


package org.example.readingserver.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;

@Data
@TableName("BOOK")
public class Book {
    @TableId(value = "ID", type = IdType.AUTO)
    private BigDecimal ID;
    private String bookname;
    private String img;
    private String booklink;
    private String uploader;
    private String hits;
    private String uploaderid;
}

package org.example.readingserver.controllers;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.extern.slf4j.Slf4j;
import org.example.readingserver.Form.MessageForm;
import org.example.readingserver.exception.MessageException;
import org.example.readingserver.pojo.Message;
import org.example.readingserver.pojo.User;
import org.example.readingserver.service.IMessageService;
import org.example.readingserver.service.IUserService;
import org.example.readingserver.vo.MessageVo;
import org.example.readingserver.vo.Result;
import org.example.readingserver.vo.UserVo;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@RestController
@Slf4j
@RequestMapping("/message")
public class MessageController {

    @Autowired
    private IUserService userService;

    @Autowired
    private IMessageService messageService;

    @PostMapping("/send")
    public Result send(@RequestBody MessageForm messageForm) {
        Message message = new Message();
        BeanUtils.copyProperties(messageForm, message);
        boolean flag = messageService.save(message);
        if (!flag) {
            throw MessageException.operationFailed();
        }
        MessageVo messageVo = new MessageVo();
        BeanUtils.copyProperties(message, messageVo);
        return Result.success(messageVo);
    }

    @PostMapping("/querySendMes/{userId}")
    public Result querySendMes(@PathVariable String userId) {
        User user = userService.getById(userId);
        if (user == null) {
            throw MessageException.notFound();
        }
        String email = user.getEmail();
        QueryWrapper<Message> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("sender", email);
        queryWrapper.eq("isdelsend", "0");
        return Result.success(messageService.list(queryWrapper));
    }

    @PostMapping("/queryRevMes/{userId}")
    public Result queryRevMes(@PathVariable String userId) {
        User user = userService.getById(userId);
        if (user == null) {
            throw MessageException.notFound();
        }
        String email = user.getEmail();
        QueryWrapper<Message> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("receiver", email);
        queryWrapper.eq("isdelrev", "0");
        return Result.success(messageService.list(queryWrapper));
    }

    @PostMapping("/read/{userId}/{mesId}")
    public Result read(@PathVariable String userId, @PathVariable String mesId) {
        User user = userService.getById(userId);
        Message message = messageService.getById(mesId);
        if (message == null) {
            throw MessageException.notFound();
        }
        String email = user.getEmail();
        String receiver = message.getReceiver();
        if(!Objects.equals(email, receiver)) {
            throw MessageException.permissionDenied();
        }

        message.setIsread("1");
        boolean flag = messageService.updateById(message);
        if (!flag) {
            throw MessageException.operationFailed();
        }

        MessageVo messageVo = new MessageVo();
        BeanUtils.copyProperties(message, messageVo);
        return Result.success(messageVo);
    }

    @PostMapping("/delSendMes/{userId}/{mesId}")
    public Result delSendMes(@PathVariable String userId, @PathVariable String mesId) {
        User user = userService.getById(userId);
        Message message = messageService.getById(mesId);
        if (message == null) {
            throw MessageException.notFound();
        }
        String email = user.getEmail();
        String sender = message.getSender();
        if(!Objects.equals(email, sender)) {
            throw MessageException.permissionDenied();
        }

        message.setIsdelsend("1");
        boolean flag = messageService.updateById(message);
        if (!flag) {
            throw MessageException.operationFailed();
        }

        MessageVo messageVo = new MessageVo();
        BeanUtils.copyProperties(message, messageVo);
        return Result.success(messageVo);
    }

    @PostMapping("/delRevMes/{userId}/{mesId}")
    public Result delRevMes(@PathVariable String userId, @PathVariable String mesId) {
        User user = userService.getById(userId);
        Message message = messageService.getById(mesId);
        if (message == null) {
            throw MessageException.notFound();
        }
        String email = user.getEmail();
        String receiver = message.getReceiver();
        if(!Objects.equals(email, receiver)) {
            throw MessageException.permissionDenied();
        }

        message.setIsdelrev("1");
        boolean flag = messageService.updateById(message);
        if (!flag) {
            throw MessageException.operationFailed();
        }

        MessageVo messageVo = new MessageVo();
        BeanUtils.copyProperties(message, messageVo);
        return Result.success(messageVo);
    }

    @PostMapping("agree")
    public Result agree(@RequestBody Message message) {
        String sender = message.getSender();
        String receiver = message.getReceiver();
        User senderUser = userService.getByEmail(sender);
        User receiverUser = userService.getByEmail(receiver);
        if (senderUser == null || receiverUser == null) {
            throw MessageException.notFound();
        }
        if(Objects.equals(receiverUser.getIsmanager(), "0") && !Objects.equals(receiverUser.getGroupid(), "-1")){
            throw MessageException.permissionDenied();
        }
        if(!Objects.equals(senderUser.getGroupid(), "-1")){
            throw MessageException.userGroupNotNull();
        }

        String groupId = receiverUser.getGroupid();
        senderUser.setGroupid(groupId);
        boolean flag = userService.updateById(senderUser);
        if (!flag) {
            throw MessageException.operationFailed();
        }
        UserVo userVo = new UserVo();
        BeanUtils.copyProperties(senderUser, userVo);

        // 处理完之后在组长中删除该信息，即在receiver中删除该信息
        delRevMes(receiverUser.getID().toString(), message.getID().toString());

        return Result.success(userVo);
    }

    @PostMapping("/sendMessage")
    public Result sendMessage(@RequestBody MessageForm messageForm) {
        Message message = new Message();
        BeanUtils.copyProperties(messageForm, message);
        message.setContent("请求加入群组");
        boolean flag = messageService.save(message);
        if (!flag) {
            throw MessageException.operationFailed();
        }
        return Result.success(true);
    }

    @PostMapping("/checkMessage/{userId}")
    public Result checkMessage(@PathVariable String userId) {
        User user = userService.getById(userId);
        if (user == null) {
            throw MessageException.notFound();
        }
        String groupId = user.getGroupid();
        if (Objects.equals(groupId, "-1")) {
            return Result.success(false);
        }
        else {
            return Result.success(true);
        }
    }

    @PostMapping("/queryMessage/{managerId}/{mesId}/{flag}")
    public Result queryMessage(@PathVariable String managerId, @PathVariable String mesId, @PathVariable String flag) {
        Message message = messageService.getById(mesId);
        if (message == null) {
            throw MessageException.notFound();
        }
        String sender = message.getSender();
        User senderUser = userService.getByEmail(sender);
        User receiverUser = userService.getById(managerId);

        if (senderUser == null || receiverUser == null) {
            throw MessageException.notFound();
        }
        if(Objects.equals(receiverUser.getIsmanager(), "0") && !Objects.equals(receiverUser.getGroupid(), "-1")){
            throw MessageException.permissionDenied();
        }
        if(!Objects.equals(senderUser.getGroupid(), "-1")){
            throw MessageException.userGroupNotNull();
        }
        if(Objects.equals(message.getIsread(), "1")){
            return Result.success("已处理过该请求");
        }

        message.setIsread("1");
        boolean flag1 = messageService.updateById(message);
        if (!flag1) {
            throw MessageException.operationFailed();
        }

        if(Objects.equals(flag, "false")) {
            return Result.success("拒绝操作成功");
        }

        String groupId = receiverUser.getGroupid();
        senderUser.setGroupid(groupId);
        boolean flag2 = userService.updateById(senderUser);
        if (!flag2) {
            throw MessageException.operationFailed();
        }
        return Result.success("同意操作成功");
    }

    @PostMapping("/sendChatMessage/{userId}")
    public Result sendChatMessages(@RequestBody MessageForm messageForm, @PathVariable String userId) {
        User user = userService.getById(userId);
        if(user == null){
            throw MessageException.notFound();
        }
        if(Objects.equals(user.getGroupid(), "-1")){
            throw MessageException.permissionDenied();
        }
        Message message = new Message();
        BeanUtils.copyProperties(messageForm, message);
        message.setSender(user.getEmail());
        message.setReceiver("all");
        message.setGroupid(user.getGroupid());
        boolean flag = messageService.save(message);
        if (!flag) {
            throw MessageException.operationFailed();
        }
        return Result.success(true);
    }

    @PostMapping("/viewChatMessages/{userId}")
    public Result viewChatMessages(@PathVariable String userId, @RequestParam(defaultValue = "1") int page,
                                   @RequestParam(defaultValue = "6") int size) {
        User user = userService.getById(userId);
        String email = user.getEmail();

        Page<Message> messagePage = new Page<>(page, size);
        QueryWrapper<Message> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("receiver", "all").eq("groupid", user.getGroupid()).orderByDesc("time");
        IPage<Message> messageResult = messageService.page(messagePage, queryWrapper);

        List messageVoList = messageResult.getRecords().stream()
                .map(message -> {
                    MessageVo messageVo = new MessageVo();
                    BeanUtils.copyProperties(message, messageVo);
                    messageVo.setID(message.getID().toString());
                    if (Objects.equals(message.getSender(), email)) {
                        messageVo.setSender("我");
                    }
                    return messageVo;
                }).collect(Collectors.toList());

        messageResult.setRecords(messageVoList);
        return Result.success(messageResult);
    }

    @PostMapping("/viewJoinRequests/{userId}")
    public Result viewJoinRequests(@PathVariable String userId, @RequestParam(defaultValue = "1") int page,
                                   @RequestParam(defaultValue = "6") int size){
        User user = userService.getById(userId);
        if (user == null) {
            throw MessageException.notFound();
        }
        if(Objects.equals(user.getIsmanager(), "0") || Objects.equals(user.getGroupid(), "-1")){
            throw MessageException.permissionDenied();
        }

        Page<Message> messagePage = new Page<>(page, size);
        QueryWrapper<Message> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("receiver", user.getEmail()).eq("content", "请求加入群组").orderByDesc("time");
        IPage<Message> messageResult = messageService.page(messagePage, queryWrapper);

        List messageVoList = messageResult.getRecords().stream()
                .map(message -> {
                    MessageVo messageVo = new MessageVo();
                    BeanUtils.copyProperties(message, messageVo);
                    messageVo.setID(message.getID().toString());
                    return messageVo;
                }).collect(Collectors.toList());

        messageResult.setRecords(messageVoList);
        return Result.success(messageResult);
    }
}

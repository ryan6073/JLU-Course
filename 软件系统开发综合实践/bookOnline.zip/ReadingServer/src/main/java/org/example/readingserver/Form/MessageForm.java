package org.example.readingserver.Form;

import lombok.Data;

@Data
public class MessageForm {
    private String time;
    private String content;
    private String sender;
    private String receiver;
}

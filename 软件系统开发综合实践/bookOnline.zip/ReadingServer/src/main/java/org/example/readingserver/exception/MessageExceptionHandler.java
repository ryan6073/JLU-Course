package org.example.readingserver.exception;

import org.example.readingserver.enums.ResultEnum;
import org.example.readingserver.vo.Result;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class MessageExceptionHandler {
    @ExceptionHandler(MessageException.class)
    public Result MessageExceptionHandler(MessageException e) {
        if(e.getMessage().endsWith(ResultEnum.ERROR_NOTFOUND.getMsg()))
            return Result.fail(ResultEnum.ERROR_NOTFOUND);
        if(e.getMessage().endsWith(ResultEnum.ERROR_OPERATION_FAILED.getMsg()))
            return Result.fail(ResultEnum.ERROR_OPERATION_FAILED);
        if(e.getMessage().endsWith(ResultEnum.ERROR_PERMISSION_DENIED.getMsg()))
            return Result.fail(ResultEnum.ERROR_PERMISSION_DENIED);
        if(e.getMessage().endsWith(ResultEnum.ERROR_USER_GROUP_NOT_NULL.getMsg()))
            return Result.fail(ResultEnum.ERROR_USER_GROUP_NOT_NULL);
        return Result.fail();
    }

//    @ExceptionHandler(Exception.class)
//    public Result ExceptionHandler(Exception e) {
//        return Result.fail();
//    }
}

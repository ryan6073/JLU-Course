package org.example.readingserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReadingServerApplicationTests {

    @Test
    void contextLoads() {
    }

}

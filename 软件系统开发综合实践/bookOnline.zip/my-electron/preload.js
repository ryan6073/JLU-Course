const {contextBridge, ipcRenderer} = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
    getPlatform: async () => await ipcRenderer.invoke('platform:get'),
    openPrompt: async (options) => await ipcRenderer.invoke('prompt-for-book-name', options)
});

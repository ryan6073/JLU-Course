const {app, BrowserWindow, ipcMain} = require('electron');
const {join} = require('path');
const electronPrompt = require('electron-prompt');

const createWindow = () => {
    const win = new BrowserWindow({
        width: 800,
        height: 600,
        autoHideMenuBar: true,
        icon: 'icon.png',
        webPreferences: {
            preload: join(__dirname, "preload.js"),
            sandbox: false,
            contextIsolation: true, // 启用上下文隔离
            enableRemoteModule: false, // 因为你正在使用 contextBridge，所以这应该设置为 false
            nodeIntegration: false, // 推荐禁用 nodeIntegration
            webSecurity: false,
            cache: false
        }
    });
    win.loadFile('index.html');
};


app.whenReady().then(() => {
    ipcMain.handle("platform:get", () => {
        return process.platform;
    });
    ipcMain.handle('prompt-for-book-name', async (event, options) => {
        return electronPrompt(options);
    });
    createWindow();
});

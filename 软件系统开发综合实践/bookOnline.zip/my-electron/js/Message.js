// document.addEventListener('DOMContentLoaded', function () {
//     adjustUIBasedOnRole(userInfo);
// });
userInfo = JSON.parse(localStorage.getItem('userInfo'));
document.querySelector(':root').style.setProperty('--button-color', localStorage.getItem('buttonColor'));

function adjustUIBasedOnRole(userInfo) {
    if (userInfo.groupid === "-1") {
        // 群众，只能看到申请消息
        document.getElementById('sendMessageBtn').style.display = 'block';
        checkMessage();
    } else if (userInfo.ismanager === "1") {
        // 组长，可以看群聊和申请消息
        document.getElementById('viewJoinRequestsBtn').style.display = 'block';
        document.getElementById('viewChatMessagesBtn').style.display = 'block';
        document.getElementById('sendChatMessageBtn').style.display = 'block';
    } else {
        // 组员，可以看群聊
        document.getElementById('viewChatMessagesBtn').style.display = 'block';
        document.getElementById('sendChatMessageBtn').style.display = 'block';
    }
}

adjustUIBasedOnRole(userInfo)

function viewChatMessages() {
    // POST localhost:8080/message/viewChatMessages/{userInfo.id}
    fetch(`http://localhost:8080/message/viewChatMessages/${userInfo.id}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        }
    }).then(response => response.json())
        .then(data => {
            if (data.code === 0) {
                if (data.data.records.length === 0) {
                    messageList.innerText = '暂无消息';
                } else {
                    messageList.innerText = '';
                    const ul = document.createElement('ul');
                    data.data.records.forEach(record => {
                        const li = document.createElement('li');
                        li.innerHTML = `<strong>时间:</strong> ${record.time}<br>
                                        <strong>内容:</strong> ${record.content}<br>
                                        <strong>发件人:</strong> ${record.sender}`;
                        ul.appendChild(li);
                    });
                    messageList.appendChild(ul);
                }
            } else {
                alert('查看失败: ' + data.message);
            }
        })
        .catch(error => {
            alert('查看过程中发生错误: ' + error.message);
        });
}

function queryMessage(id, flag) {
    // POST localhost:8080/message/queryMessage/{userInfo.id}/{id}/flag
    fetch(`http://localhost:8080/message/queryMessage/${userInfo.id}/${id}/${flag}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        }
    }).then(response => response.json())
        .then(data => {
            if (data.code === 0) {
                alert(data.data);
                viewJoinRequests();
            } else {
                alert('操作失败: ' + data.message);
            }
        })
        .catch(error => {
            alert('操作过程中发生错误: ' + error.message);
        });
}

function viewJoinRequests() {
    // POST localhost:8080/message/viewJoinRequests/{userInfo.id}
    fetch(`http://localhost:8080/message/viewJoinRequests/${userInfo.id}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        }
    }).then(response => response.json())
        .then(data => {
            if (data.code === 0) {
                if (data.data.records.length === 0) {
                    messageList.innerText = '暂无申请消息';
                } else {
                    messageList.innerText = '';
                    const ul = document.createElement('ul');
                    data.data.records.forEach(record => {
                        const li = document.createElement('li');
                        li.innerHTML = `<strong>时间:</strong> ${record.time}<br>
                                        <strong>内容:</strong> ${record.content}<br>
                                        <strong>申请人:</strong> ${record.sender}`;
                        if (record.isread === '1') {
                            li.innerHTML += '<br><strong>状态:</strong> 已通过';
                        } else {
                            // 创建同意按钮
                            const approveBtn = document.createElement('button');
                            approveBtn.innerHTML = '✔️';
                            approveBtn.onclick = function () {
                                queryMessage(record.id, true);
                            };
                            approveBtn.style.marginLeft = '100px';

                            // 创建拒绝按钮
                            const rejectBtn = document.createElement('button');
                            rejectBtn.innerHTML = '❌';
                            rejectBtn.onclick = function () {
                                queryMessage(record.id, false);
                            };
                            rejectBtn.style.marginLeft = '50px';

                            li.appendChild(approveBtn);
                            li.appendChild(rejectBtn);
                        }
                        ul.appendChild(li);
                    });
                    messageList.appendChild(ul);
                }
            } else {
                alert('查看失败: ' + data.message);
            }
        })
        .catch(error => {
            alert('查看过程中发生错误: ' + error.message);
        });
}

function sendMessage() {
    // const message = prompt("Enter your message:");
    // 发送消息逻辑，根据是发送到群聊还是作为申请消息发送给组长:组长Email（收件人），消息，发件人Email，时间
    const content = prompt("Enter your message:");
    const receiver = prompt("Enter recipient email:");
    const sender = userInfo.email;
    //time的格式是2024-05-10 14:06，注意不需要精确到秒
    const time = new Date().toISOString().slice(0, 16).replace('T', ' ');
    //如果receiver非空
    if (receiver) {
        // POST localhost:8080/message/sendMessage
        fetch('http://localhost:8080/message/sendMessage', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                receiver: receiver,
                content: content,
                sender: sender,
                time: time
            })
        }).then(response => response.json())
            .then(data => {
                if (data.code === 0) {
                    alert('发送成功！');
                } else {
                    alert('发送失败: ' + data.message);
                }
            })
            .catch(error => {
                alert('发送过程中发生错误: ' + error.message);
            });
    } else {
        alert('取消发送');
    }
}

function sendChatMessage() {
    //POST
    // localhost:8080/message/sendChatMessage/0
    const message = prompt("输入你的聊天内容：");
    const time = new Date().toISOString().slice(0, 16).replace('T', ' ');
    fetch(`http://localhost:8080/message/sendChatMessage/${userInfo.id}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            content: message,
            time: time
        })
    }).then(response => response.json())
        .then(data => {
            if (data.code === 0) {
                alert('发送成功！');
            } else {
                alert('发送失败: ' + data.message);
            }
        })
        .catch(error => {
            alert('发送过程中发生错误: ' + error.message);
        });
    viewChatMessages();
}

function checkMessage() {
    //　POST localhost:8080/message/checkMessage/{userInfo.id}
    fetch(`http://localhost:8080/message/checkMessage/${userInfo.id}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        }
    }).then(response => response.json())
        .then(data => {
            if (data.code === 0) {
                if (data.data === false) {
                    document.getElementById('messageList').innerText = '暂无消息';
                } else {
                    // document.getElementById('messageList').innerText = data.data;
                }
            } else {
                alert('查看失败: ' + data.message);
            }
        })
        .catch(error => {
            alert('查看过程中发生错误: ' + error.message);
        });
}
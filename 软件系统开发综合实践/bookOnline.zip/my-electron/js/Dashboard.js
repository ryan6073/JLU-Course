// Ensure global variables are not redeclared
window.currentPage = window.currentPage || 1;
window.totalPages = window.totalPages || 0;
window.currentPdfPath = window.currentPdfPath || '';
var userInfo = JSON.parse(localStorage.getItem('userInfo'));
var bookInfo = JSON.parse(localStorage.getItem('bookInfo'));
document.querySelector(':root').style.setProperty('--button-color', localStorage.getItem('buttonColor'));

function fetchBooks(page) {
    fetch(`http://localhost:8080/book/list?page=${page}&size=12`, {
        method: 'GET',
        headers: {'Content-Type': 'application/json'}
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok.');
            }
            return response.json();
        })
        .then(data => {
            if (data && data.data) {
                totalPages = data.data.pages; // Assuming 'pages' is correctly provided
                currentPage = page;
                populateBooks(data);
                updatePagination();
            } else {
                throw new Error('Invalid data structure from API');
            }
        })
        .catch(error => {
            console.error('Error loading content:', error);
            // Optionally update the UI to reflect the error
        });
}


function populateBooks(responseData) {
    const books = responseData.data.records;
    const container = document.getElementById('bookContainer');
    container.innerHTML = ''; // 清除现有内容

    books.forEach(function (book) {
        var col = document.createElement('div');
        col.className = 'col';
        var link = document.createElement('button'); // 改为按钮以避免默认链接行为
        link.className = 'da-book-link';
        link.onclick = function () {
            showBookDetails(book);
        }; // 点击时显示详情而不是直接打开PDF
        var hoverDiv = document.createElement('div');
        hoverDiv.className = 'hover';
        var padDiv = document.createElement('div');
        padDiv.className = 'pad align-bottom';
        var title = document.createElement('h2');
        title.textContent = book.bookname;

        // var bgImg = document.createElement('div');
        // bgImg.className = 'bg-img';
        // bgImg.style.backgroundImage = 'url(src/upload/' + book.img + ')';
        var bgImg = new Image();
        bgImg.src = 'src/upload/' + book.img;
        bgImg.className = 'bg-img';


        padDiv.appendChild(title);
        hoverDiv.appendChild(padDiv);
        link.appendChild(hoverDiv);
        col.appendChild(bgImg);
        col.appendChild(link);
        container.appendChild(col);
    });
}

function showBookDetails(book) {
    const bookDetails = document.getElementById('bookDetails');
    const detailsContent = document.getElementById('detailsContent');
    const paginationContent = document.getElementById('pagination');

    detailsContent.innerHTML = '<p>Loading book details...</p>';
    bookDetails.style.display = 'block';
    paginationContent.style.display = 'none';
    document.getElementById('bookShelf').style.display = 'none';

    fetch(`http://localhost:8080/book/detail/${book.id}`)
        .then(response => response.json())
        .then(data => {
            if (data.code === 0) {
                // Saving PDF path
                currentPdfPath = `src/bookPDF/${data.data.booklink}`;
                localStorage.setItem('bookInfo', JSON.stringify(data.data));
                // Update details content
                detailsContent.innerHTML = `
                    <h1>${data.data.bookname}</h1>
                    <img src="src/upload/${data.data.img}" alt="${data.data.bookname}" style="max-width: 20%;">
                    <p>Uploader: ${data.data.uploader}</p>
                    <p>Views: ${data.data.hits}</p>
                `;
                document.getElementById('readBook').onclick = function () {
                    openPdfViewer(data.data.id);  // 确保这里的 someIdVariable 是在这个上下文中已定义且有效的
                };

            } else {
                detailsContent.innerHTML = `<p>Error loading details: ${data.message}</p>`;
            }
        })
        .catch(error => {
            detailsContent.innerHTML = `<p>Network or server error: ${error}</p>`;
        });

    fetch(`http://localhost:8080/favor/queryFavor/${userInfo.id}/${book.id}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    }).then(response => response.json())
        .then(data => {
                if (data.code === 0) {
                    const likeButton = document.getElementById('likeButton');
                    const heartIcon = likeButton.querySelector('i');
                    const likeStatus = document.getElementById('likeStatus');
                    if (data.data) {
                        heartIcon.classList.remove('fa-regular');
                        heartIcon.classList.add('fa-solid');
                        likeStatus.textContent = '已喜欢';
                    } else {
                        heartIcon.classList.remove('fa-solid');
                        heartIcon.classList.add('fa-regular');
                        likeStatus.textContent = '未喜欢';
                    }
                } else {
                    alert('Error loading like status: ' + data.message);
                }
            }
        ).catch(error => {
            alert('Network or server error: ' + error)
        }
    );
}

function closeBookDetails() {
    document.getElementById('bookDetails').style.display = 'none';
    document.getElementById('bookShelf').style.display = 'block'; // 重新显示图书列表
    document.getElementById('pagination').style.display = 'block';
}

function openPdfViewer(id) {
    fetch(`http://localhost:8080/book/read/${id}`, {
        method: 'POST', // Specify the method as POST
        headers: {
            'Content-Type': 'application/json'
        }
    })
        .then(response => response.json())
        .then(data => {
            if (data.code === 0) {
                const pdfViewer = document.getElementById('pdfViewer');
                const pdfPath = "src/bookPDF/" + data.data.booklink;
                if (pdfPath) {
                    pdfViewer.querySelector('iframe').src = pdfPath;
                    pdfViewer.style.display = 'block';
                    document.querySelector('.main').style.display = 'none';
                    document.getElementById('bookDetails').style.display = 'none';
                    document.getElementById('pagination').style.display = 'none';
                } else {
                    alert('No PDF link found! Please try again.');
                }
            } else {
                alert('Error loading details: ' + data.message);
            }
        })
        .catch(error => {
            alert('Network or server error: ' + error)
        });
}

function closePdfViewer() {
    const pdfViewer = document.getElementById('pdfViewer');
    pdfViewer.style.display = 'none'; // Hide the PDF viewer
    document.getElementById('bookDetails').style.display = 'block'; // Show the book details again
    document.querySelector('.main').style.display = 'none'; // Keep the main container hidden
    pdfViewer.querySelector('iframe').src = ''; // Clear the iframe source to free up resources and ensure privacy
    document.getElementById('pagination').style.display = 'block';
}

// function updatePagination() {
//     const pageInfo = document.getElementById('pageInfo');
//     const prevPage = document.getElementById('prevPage');
//     const nextPage = document.getElementById('nextPage');
//
//     if (totalPages > 0) {
//         pageInfo.textContent = `第 ${currentPage} 页，共 ${totalPages} 页`;
//         prevPage.disabled = currentPage <= 1;
//         nextPage.disabled = currentPage >= totalPages;
//     } else {
//         pageInfo.textContent = "没有更多的页面";
//         prevPage.disabled = true;
//         nextPage.disabled = true;
//     }
// }

function updatePagination() {
    document.getElementById('pagination').style.display = 'block';
    const pageInfo = document.getElementById('pageInfo');
    if (pageInfo) {
        pageInfo.textContent = `第 ${currentPage} 页，共 ${totalPages} 页`;
        const prevPage = document.getElementById('prevPage');
        const nextPage = document.getElementById('nextPage');
        prevPage.disabled = currentPage <= 1;
        nextPage.disabled = currentPage >= totalPages;
    } else {
        console.error("未在DOM中找到pageInfo元素");
    }
}

document.getElementById('likeButton').addEventListener('click', function () {
    const heartIcon = this.querySelector('i');
    const likeStatus = document.getElementById('likeStatus');
    const userId = userInfo.id;
    const bookId = bookInfo.id;

    const bodyData = {
        userid: userId,
        bookid: bookId
    };
    if (heartIcon.classList.contains('fa-regular')) {
        // 当前是空心，变为实心，发送喜欢请求
        fetch('http://localhost:8080/favor/add', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(bodyData)
        })
            .then(response => {
                if (response.ok) {
                    heartIcon.classList.remove('fa-regular');
                    heartIcon.classList.add('fa-solid');
                    likeStatus.textContent = '已喜欢';
                } else {
                    throw new Error('Failed to add favorite');
                }
            })
            .catch(error => console.error('Error:', error));
    } else {
        // 当前是实心，变为空心，发送撤销喜欢请求
        fetch('http://localhost:8080/favor/delete', {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(bodyData)
        })
            .then(response => {
                if (response.ok) {
                    heartIcon.classList.remove('fa-solid');
                    heartIcon.classList.add('fa-regular');
                    likeStatus.textContent = '未喜欢';
                } else {
                    throw new Error('Failed to delete favorite');
                }
            })
            .catch(error => console.error('Error:', error));
    }
});


function changePage(change) {
    const newPage = currentPage + change;
    if (newPage > 0 && newPage <= totalPages) {
        fetchBooks(newPage);
    }
}

// Make window height adjustments
function makeWinHeight() {
    var vh = $('.dashboard-box').height();
    $('#dashboard, .layer.main').height(vh);
    var projects = vh / 2;
    $('#dashboard .col a, #dashboard .col').height(projects);
}

$(document).ready(function () {
    makeWinHeight();
    fetchBooks(1);
});

$(window).resize(function () {
    makeWinHeight();
});

// Initialize Parallax effect if needed
var scene = document.getElementById('dashboard');
if (scene) {
    var parallax = new Parallax(scene);
    console.log(parallax);
}


// document.addEventListener('DOMContentLoaded', () => {
//     console.log('File page specific JavaScript');
// });

// Ensure global variables are not redeclared
window.currentFilePage = window.currentFilePage || 1;
window.totalFilePages = window.totalFilePages || 0;
var userInfo = JSON.parse(localStorage.getItem('userInfo'));
var bookInfo = JSON.parse(localStorage.getItem('bookInfo'));
document.querySelector(':root').style.setProperty('--button-color', localStorage.getItem('buttonColor'));

function fetchBooks(page) {
    fetch(`http://localhost:8080/book/search/${userInfo.id}?page=${page}`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'}
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok.');
            }
            return response.json();
        })
        .then(data => {
            if (data && data.data) {
                totalFilePages = data.data.pages; // Assuming 'pages' is correctly provided
                currentFilePage = page;
                populateBooks(data);
                updatePagination();
            } else {
                throw new Error('Invalid data structure from API');
            }
        })
        .catch(error => {
            console.error('Error loading content:', error);
            // Optionally update the UI to reflect the error
        });
}

function populateBooks(responseData) {
    const books = responseData.data.records;
    const container = document.getElementById('bookContainer');
    container.innerHTML = ''; // 清除现有内容
    container.className = 'book-grid'; // 设置网格布局的类名

    books.forEach(function (book, index) {
        if (index < 6) { // 限制最多显示6个图书
            var col = document.createElement('div');
            col.className = 'col';

            var link = document.createElement('button');
            link.className = 'book-link';
            link.style.width = '100%'; // 设置 link 按钮占满整个列宽
            link.onclick = function () {
                showBookDetails(book);
            };

            var hoverDiv = document.createElement('div');
            hoverDiv.className = 'hover';
            var padDiv = document.createElement('div');
            padDiv.className = 'pad align-bottom';
            var title = document.createElement('h2');
            title.textContent = book.bookname;

            var bgImg = new Image();
            bgImg.src = 'src/upload/' + book.img;
            bgImg.className = 'bg-img';

            padDiv.appendChild(title);
            hoverDiv.appendChild(padDiv);
            link.appendChild(hoverDiv);
            col.appendChild(bgImg);
            col.appendChild(link);

            // 创建按钮容器
            var buttonContainer = document.createElement('div');
            buttonContainer.className = 'button-container';
            buttonContainer.style.display = 'flex';
            buttonContainer.style.width = '100%'; // 容器宽度100%

            // 创建删除按钮
            var deleteButton = document.createElement('button');
            deleteButton.textContent = '删除';
            deleteButton.className = 'delete-btn';
            deleteButton.style.width = '50%'; // 按钮宽度50%
            deleteButton.onclick = function () {
                deleteBook(book.id); // 调用删除图书函数
            };

            // 创建重命名按钮
            var renameButton = document.createElement('button');
            renameButton.textContent = '改名';
            renameButton.className = 'rename-btn';
            renameButton.style.width = '50%'; // 按钮宽度50%
            renameButton.onclick = function () {
                renameBook(book.id); // 调用重命名图书函数
            };

            // 将按钮添加到按钮容器
            buttonContainer.appendChild(deleteButton);
            buttonContainer.appendChild(renameButton);

            // 将按钮容器添加到列
            col.appendChild(buttonContainer);

            // 将列添加到容器
            container.appendChild(col);
        }
    });
}

function showBookDetails(book) {
    const bookDetails = document.getElementById('bookDetails');
    const detailsContent = document.getElementById('detailsContent');
    const paginationContent = document.getElementById('pagination');

    detailsContent.innerHTML = '<p>Loading book details...</p>';
    bookDetails.style.display = 'block';
    paginationContent.style.display = 'none';
    document.getElementById('bookShelf').style.display = 'none';
    document.getElementById('topControls').style.display = 'none';

    fetch(`http://localhost:8080/book/detail/${book.id}`)
        .then(response => response.json())
        .then(data => {
            if (data.code === 0) {
                // Saving PDF path
                currentPdfPath = `src/bookPDF/${data.data.booklink}`;
                localStorage.setItem('bookInfo', JSON.stringify(data.data));
                // Update details content
                detailsContent.innerHTML = `
                    <h1>${data.data.bookname}</h1>
                    <img src="src/upload/${data.data.img}" alt="${data.data.bookname}" style="max-width: 20%;">
                    <p>Uploader: ${data.data.uploader}</p>
                    <p>Views: ${data.data.hits}</p>
                `;
                document.getElementById('readBook').onclick = function () {
                    openPdfViewer(data.data.id);  // 确保这里的 someIdVariable 是在这个上下文中已定义且有效的
                };

            } else {
                detailsContent.innerHTML = `<p>Error loading details: ${data.message}</p>`;
            }
        })
        .catch(error => {
            detailsContent.innerHTML = `<p>Network or server error: ${error}</p>`;
        });
}

function closeBookDetails() {
    var bookDetails = document.getElementById('bookDetails');
    bookDetails.style.display = 'none';
    document.getElementById('bookShelf').style.display = 'block'; // 重新显示图书列表
    document.getElementById('pagination').style.display = 'block';
    bookDetails.classList.remove('show'); // 移除 'show' 类来隐藏
    document.getElementById('topControls').style.display = 'block'; // 重新显示顶部控件
}

function openPdfViewer(id) {
    fetch(`http://localhost:8080/book/read/${id}`, {
        method: 'POST', // Specify the method as POST
        headers: {
            'Content-Type': 'application/json'
        }
    })
        .then(response => response.json())
        .then(data => {
            if (data.code === 0) {
                const pdfViewer = document.getElementById('pdfViewer');
                const pdfPath = "src/bookPDF/" + data.data.booklink;
                if (pdfPath) {
                    pdfViewer.querySelector('iframe').src = pdfPath;
                    pdfViewer.style.display = 'block';
                    document.querySelector('.main').style.display = 'none';
                    document.getElementById('bookDetails').style.display = 'none';
                    document.getElementById('pagination').style.display = 'none';
                } else {
                    alert('No PDF link found! Please try again.');
                }
            } else {
                alert('Error loading details: ' + data.message);
            }
        })
        .catch(error => {
            alert('Network or server error: ' + error)
        });
}

function closePdfViewer() {
    const pdfViewer = document.getElementById('pdfViewer');
    pdfViewer.style.display = 'none'; // Hide the PDF viewer
    pdfViewer.classList.remove('show'); // 移除 'show' 类来隐藏
    document.getElementById('bookDetails').style.display = 'block'; // Show the book details again
    document.querySelector('.main').style.display = 'none'; // Keep the main container hidden
    pdfViewer.querySelector('iframe').src = ''; // Clear the iframe source to free up resources and ensure privacy
    document.getElementById('pagination').style.display = 'block';
}

function updatePagination() {
    document.getElementById('pagination').style.display = 'block';
    const pageInfo = document.getElementById('pageInfo');
    if (pageInfo) {
        pageInfo.textContent = `第 ${currentFilePage} 页，共 ${totalFilePages} 页`;
        const prevPage = document.getElementById('prevPage');
        const nextPage = document.getElementById('nextPage');
        prevPage.disabled = currentFilePage <= 1;
        nextPage.disabled = currentFilePage >= totalFilePages;
    } else {
        console.error("未在DOM中找到pageInfo元素");
    }
}

function changePage(change) {
    const newPage = currentFilePage + change;
    if (newPage > 0 && newPage <= totalFilePages) {
        fetchBooks(newPage);
    }
}

function uploadPDF() {
    const fileInput = document.getElementById('pdfFile');
    const file = fileInput.files[0];
    if (!file) {
        alert('No file selected!');
    }
    const formData = new FormData();
    formData.append('file', file);

    return fetch(`http://localhost:8080/uploadPDF/${userInfo.id}`, {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.code === 0) {
                alert('PDF uploaded successfully ${file.name}');
                return file.name; // 返回文件名
            } else {
                alert('Error uploading PDF: ' + data.message);
            }
        })
        .catch(error => {
            alert('Network or server error: ' + error);
        });
}

function uploadImage() {
    const fileInput = document.getElementById('imageFile');
    const file = fileInput.files[0];
    if (!file) {
        alert('未选择文件！');
    }
    const formData = new FormData();
    formData.append('file', file);

    return fetch(`http://localhost:8080/uploadImg`, {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.code === 0) {
                alert(`图片上传成功！${file.name}`);
                return file.name; // 当成功时确保返回文件名
            } else {
                alert('上传图片出错: ' + data.message);
            }
        })
        .catch(error => {
            alert('网络或服务器错误: ' + error);
        });
}

function addBook() {
    window.electronAPI.openPrompt({
        title: 'Enter Book Name',
        label: 'Book Name:',
        type: 'input'  // This ensures a text box is shown
    }).then((bookName) => {
        if (!bookName) {
            alert('Book name is required!');
            return;
        }
        Promise.all([uploadPDF(), uploadImage()]).then(links => {
            const [fileLink, imgLink] = links;
            fetch(`http://localhost:8080/book/add`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    bookname: bookName,
                    uploader: userInfo.username,
                    uploaderid: userInfo.id,
                    booklink: fileLink,
                    img: imgLink
                })
            })
                .then(response => response.json())
                .then(data => {
                    if (data.code === 0) {
                        alert('Book added successfully!');
                        fetchBooks(1); // Assuming fetchBooks is a function to refresh the book list
                    } else {
                        alert('Error adding book: ' + data.message);
                    }
                })
                .catch(error => {
                    alert('Network or server error: ' + error);
                });
        }).catch(error => {
            alert('Error with uploading files: ' + error);
        });
    })
        .catch(console.error);
}


function deleteBook(id) {
    //DELETE localhost:8080/book/delete/${id}/${userInfo.id}
    fetch(`http://localhost:8080/book/delete/${id}/${userInfo.id}`, {
        method: 'DELETE'
    })
        .then(response => response.json())
        .then(data => {
            if (data.code === 0) {
                alert('Book deleted successfully!');
                fetchBooks(1);
            } else {
                alert('Error deleting book: ' + data.message);
            }
        })
        .catch(error => {
            alert('Network or server error: ' + error)
        });
    fetchBooks(1);
}

function renameBook(id) {
    window.electronAPI.openPrompt({
        title: 'Rename Book',
        label: 'Enter new book name:',
        type: 'input'
    })
        .then((newBookName) => {
            if (!newBookName) {
                alert('Book name cannot be empty!');
                return;
            }
            fetch(`http://localhost:8080/book/edit/${userInfo.id}/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({bookname: newBookName})
            })
                .then(response => response.json())
                .then(data => {
                    if (data.code === 0) {
                        alert('Book renamed successfully!');
                        fetchBooks(1); // Refresh the book list
                    } else {
                        alert('Error renaming book: ' + data.message);
                    }
                })
                .catch(error => {
                    alert('Network or server error: ' + error);
                });
        })
        .catch(console.error);
}

// Make window height adjustments
function makeWinHeight() {
    var vh = $('.file-box').height();
    $('#fileSection, .layer.main').height(vh);
    var projects = vh / 2;
    $('#fileSection .col a, #fileSection .col').height(projects);
}

$(document).ready(function () {
    makeWinHeight();
    fetchBooks(1);
});

$(window).resize(function () {
    makeWinHeight();
});

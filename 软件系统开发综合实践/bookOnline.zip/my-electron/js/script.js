const sidebar = document.querySelector('.sidebar'),
    toggleBtn = document.querySelector('.toggle-btn');

toggleBtn.addEventListener('click', () => {
    sidebar.classList.toggle('active');
});

// 在函数外部获取所有列表项和主内容区域的引用
const listItems = document.querySelectorAll('.sidebar .list-item');
const mainContent = document.querySelector('.main-content');

// 异步函数来获取平台信息并根据平台调整UI和功能
(async () => {
    const platform = await window.electronAPI?.getPlatform() ?? "web";
    console.log(platform);
    // 根据平台调整可用的功能
    if (platform === "win32") {
        // 如果是桌面端，开放所有功能
        enableAllFeatures();
    } else if (platform === "web") {
        // 如果是Web端，限制某些功能
        limitSomeFeatures();
    }
})();

function enableAllFeatures() {
    listItems.forEach(item => {
        item.addEventListener('click', eventHandler);
    });
}

function limitSomeFeatures() {
    // 仅为特定的功能项添加事件监听器
    // File,Group不能正常使用
    allowlist = ['Dashboard', 'User', 'Settings', 'Analytics', 'Message', 'Favor'];
    listItems.forEach((item) => {
        if (allowlist.includes(item.querySelector('.link-name').textContent.trim())) {
            item.addEventListener('click', eventHandler);
        } else {
            item.addEventListener('click', privilegeCheck);
        }
    });
}

function privilegeCheck() {
    alert('You are using the web version of the app. Some features may be limited.');
}

function eventHandler() {
    mainContent.innerHTML = '<p>Loading content...</p>';
    listItems.forEach(innerItem => innerItem.classList.remove('active'));
    this.classList.add('active');
    const view = this.querySelector('.link-name').textContent.trim().toLowerCase();
    fetch(`./subInterface/${view}.html`)
        .then(response => response.text())
        .then(html => {
            mainContent.innerHTML = html;
            return view;
        })
        .then(view => {
            updateResources(view);
        })
        .catch(error => console.error('Error loading content:', error));
}

function updateResources(view) {
    const script = document.createElement('script');
    script.src = `./js/${view}.js`;
    script.onload = () => {
        console.log(`${view}.js loaded successfully`);
    };
    document.body.appendChild(script);

    const cssLink = document.createElement('link');
    cssLink.href = `./css/${view}.css`;
    cssLink.rel = 'stylesheet';
    cssLink.onload = () => {
        console.log(`${view}.css loaded successfully`);
    };
    document.head.appendChild(cssLink);
}

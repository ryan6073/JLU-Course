document.addEventListener('DOMContentLoaded', function () {
    console.log('Favor page specific JavaScript');
});

var userInfo = JSON.parse(localStorage.getItem('userInfo'));
var bookInfo = JSON.parse(localStorage.getItem('bookInfo'));
document.querySelector(':root').style.setProperty('--button-color', localStorage.getItem('buttonColor'));

function closeBookDetails() {
    document.getElementById('bookDetails').style.display = 'none';
    document.getElementById('bookShelf').style.display = 'block'; // 重新显示图书列表
}

function closePdfViewer() {
    const pdfViewer = document.getElementById('pdfViewer');
    pdfViewer.style.display = 'none'; // Hide the PDF viewer
    document.getElementById('bookDetails').style.display = 'block'; // Show the book details again
    pdfViewer.querySelector('iframe').src = ''; // Clear the iframe source to free up resources and ensure privacy
}

function showFavorBookDetails(id) {
    const bookDetails = document.getElementById('bookDetails');
    bookDetails.style.display = 'block';
    document.getElementById('bookShelf').style.display = 'none';

    fetch(`http://localhost:8080/book/detail/${id}`)
        .then(response => response.json())
        .then(data => {
            if (data.code === 0) {
                // Saving PDF path
                currentPdfPath = `src/bookPDF/${data.data.booklink}`;
                localStorage.setItem('bookInfo', JSON.stringify(data.data));
                // Update details content
                const detailsContent = document.getElementById('detailsContent');
                detailsContent.innerHTML = `
                    <h1>${data.data.bookname}</h1>
                    <img src="src/upload/${data.data.img}" alt="${data.data.bookname}" style="max-width: 20%;">
                    <p>Uploader: ${data.data.uploader}</p>
                    <p>Hits: ${data.data.hits}</p>
                `;
                document.getElementById('readBook').onclick = function () {
                    openPdfViewer(data.data.id);
                };

            } else {
                detailsContent.innerHTML = `<p>Error loading details: ${data.message}</p>`;
            }
        })
        .catch(error => {
            detailsContent.innerHTML = `<p>Network or server error: ${error}</p>`;
        });
}

function openPdfViewer(id) {
    fetch(`http://localhost:8080/book/read/${id}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
        .then(response => response.json())
        .then(data => {
            if (data.code === 0) {
                const pdfViewer = document.getElementById('pdfViewer');
                const pdfPath = "src/bookPDF/" + data.data.booklink;
                if (pdfPath) {
                    pdfViewer.querySelector('iframe').src = pdfPath;
                    pdfViewer.style.display = 'block';
                    document.getElementById('bookDetails').style.display = 'none';
                    document.getElementById('bookShelf').style.display = 'none';
                } else {
                    alert('No PDF link found! Please try again.');
                }
            } else {
                alert('Error loading details: ' + data.message);
            }
        })
        .catch(error => {
            alert('Network or server error: ' + error)
        });
}


function renderBooks(books) {
    const bookShelf = document.getElementById('bookShelf');
    bookShelf.innerHTML = ''; // Clear the book shelf
    books.forEach(function (book) {
            const bookDiv = document.createElement('div');
            bookDiv.className = 'book';
            bookDiv.innerHTML = `
            <div class="favor-card">
                <img src="src/upload/${book.img}" alt="${book.bookname}" class="cover" />
                <div class="title">${book.bookname}</div>
                <div class="uploader">${book.uploader}</div>
                <div class="action">
                    <button class="view-btn" onclick="showFavorBookDetails(${book.id})">查看详情</button>
                </div>
            </div> 
            `;
            bookShelf.appendChild(bookDiv);
        }
    );
}


// localhost:8080/favor/showFavor/1 POST
fetch(`http://localhost:8080/favor/showFavor/${userInfo.id}`, {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    }
}).then(response => response.json())
    .then(data => {
        console.log(data);
        if (data.code === 0) {
            // 渲染图书列表
            renderBooks(data.data);
        } else {
            alert("还没有喜欢的图书，快去大厅看看吧！");
        }
    });

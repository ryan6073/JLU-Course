window.signInBtn = document.getElementById("signIn");
window.signUpBtn = document.getElementById("signUp");
window.firstForm = document.getElementById("form1");
window.secondForm = document.getElementById("form2");
window.loginContainer = document.querySelector(".login-container");
document.querySelector(':root').style.setProperty('--button-color', localStorage.getItem('buttonColor'));

function updateUIBasedOnLoginStatus() {
    const userInfo = localStorage.getItem('userInfo');
    const loginContainer = document.querySelector(".login-container");
    const userDetailsDisplay = document.querySelector(".user-details");
    const nicknameSpan = document.getElementById("nickname");
    const emailSpan = document.getElementById("account-email");
    const avatarImg = document.getElementById("avatar");

    if (userInfo) {
        loginContainer.style.display = 'none'; // 如果已登录，隐藏登录/注册表单
        userDetailsDisplay.style.display = 'block'; // 显示用户信息

        const user = JSON.parse(userInfo);
        nicknameSpan.textContent = user.username; // 假设用户信息中有 'username' 字段
        emailSpan.textContent = user.email; // 假设用户信息中有 'email' 字段
        avatarImg.src = `src/upload/${user.avatar}`; // 假设用户信息中有 'avatar' 字段
    } else {
        loginContainer.style.display = 'block'; // 如果未登录，显示登录/注册表单
        userDetailsDisplay.style.display = 'none'; // 隐藏用户信息显示区域
        // 重置到默认访客信息
        nicknameSpan.textContent = "Visitor";
        emailSpan.textContent = "visitor@example.com";
    }
}


updateUIBasedOnLoginStatus();

signInBtn.addEventListener("click", () => {
    loginContainer.classList.remove("right-panel-active");
});

signUpBtn.addEventListener("click", () => {
    loginContainer.classList.add("right-panel-active");
});

function serializeFormToJson(form) {
    const formData = new FormData(form);
    let obj = {};
    formData.forEach((value, key) => {
        if (obj[key]) {
            if (!Array.isArray(obj[key])) {
                obj[key] = [obj[key]];
            }
            obj[key].push(value);
        } else {
            obj[key] = value;
        }
    });
    return JSON.stringify(obj);
}

firstForm.addEventListener("submit", function (e) {
    e.preventDefault();
    const jsonData = serializeFormToJson(this);
    console.log(jsonData);

    fetch('http://localhost:8080/user/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: jsonData
    })
        .then(response => response.json())
        .then(data => {
            if (data.code === 0) {
                alert('注册成功！');
                //点击到登录页面
                document.querySelector('.login-container').classList.remove('right-panel-active');
            } else {
                alert('注册失败: ' + data.message);
            }
        })
        .catch(error => {
            alert('注册过程中发生错误: ' + error.message);
        });

});


secondForm.addEventListener("submit", function (e) {
    e.preventDefault();
    const jsonData = serializeFormToJson(this);

    fetch('http://localhost:8080/user/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: jsonData
    })
        .then(response => response.json())
        .then(data => {
            if (data.code === 0) {
                alert(`欢迎回来：${data.data.username}`);
                localStorage.setItem('userInfo', JSON.stringify(data.data));
                //点击dashboard
                document.querySelector('.list-item a[href="#"] .link-name[style="--i: 1;"]').click();

            } else {
                alert('登录失败: ' + data.message);
            }
        })
        .catch(error => {
            alert('登录过程中发生错误: ' + error.message);
        });
});

document.getElementById('logoutButton').addEventListener('click', function () {
    localStorage.removeItem('userInfo');
    //重新点击侧边栏的user
    document.querySelector('.list-item a[href="#"] .link-name[style="--i: 2;"]').click();
});

document.getElementById('file').addEventListener('change', function () {
    var avatarImage = document.getElementById('avatar');
    var userInfo = JSON.parse(localStorage.getItem('userInfo'));
    if (this.files && this.files[0]) {
        var file = this.files[0];
        var formData = new FormData();
        formData.append('file', file);

        fetch('http://localhost:8080/uploadImg', {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (data.code === 0) {
                    // 假设服务器返回新图片的 URL 在 data.imageUrl
                    alert('图片上传成功！');
                } else {
                    alert('上传图片出错: ' + data.message);
                }
            })
            .catch(error => {
                alert('图片上传过程中发生错误: ' + error.message);
            });

        //POST localhost:8080/user/edit/${userInfo.id}
        fetch(`http://localhost:8080/user/edit/${userInfo.id}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({avatar: file.name})
        })
            .then(response => response.json())
            .then(data => {
                if (data.code === 0) {
                    alert('头像更新成功！');
                } else {
                    alert('头像更新失败: ' + data.message);
                }
            })
            .catch(error => {
                alert('头像更新过程中发生错误: ' + error.message);
            });
        avatarImage.src = 'src/upload/' + file.name; // 更新图片显示
        userInfo.avatar = file.name; // 更新用户信息
        window.localStorage.setItem('userInfo', JSON.stringify(userInfo)); // 更新本地存储
    }

});

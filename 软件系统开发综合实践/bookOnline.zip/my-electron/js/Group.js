var userInfo = JSON.parse(localStorage.getItem('userInfo'));
var groupInfo = JSON.parse(localStorage.getItem('groupInfo'));
document.querySelector(':root').style.setProperty('--button-color', localStorage.getItem('buttonColor'));

function refreshUserInfo() {
    var storedUserInfo = localStorage.getItem('userInfo');
    if (storedUserInfo) {
        userInfo = JSON.parse(storedUserInfo);
    } else {
        console.error('No userInfo in localStorage');
    }
}

function updateUserInfoAndRefresh(data) {
    localStorage.setItem('userInfo', JSON.stringify(data));
    refreshUserInfo();
    checkGroup(); // 重新检查小组状态并更新UI
}

function updateGroupInfoAndRefresh(data) {
    localStorage.setItem('groupInfo', JSON.stringify(data));
    refreshGroupInfo();
    showGroupInfo(); // 重新显示小组信息
}

function refreshGroupInfo() {
    var storedGroupInfo = localStorage.getItem('groupInfo');
    if (storedGroupInfo) {
        groupInfo = JSON.parse(storedGroupInfo);
    } else {
        console.error('No groupInfo in localStorage');
    }
}

function checkGroup() {
    refreshUserInfo();
    //如果userInfo.groupid=-1,则显示创建小组或者加入小组的按钮；否则显示小组信息
    if (userInfo.groupid === "-1") {
        document.getElementById('groupContent').style.display = 'none';
        document.getElementById('groupHeader').style.display = 'block';
    } else {
        document.getElementById('groupContent').style.display = 'block';
        document.getElementById('groupHeader').style.display = 'none';
        checkManager();
    }
}

function checkManager() {

    if (userInfo.ismanager === "0") {
        document.getElementById('MemberSubpage').style.display = 'block';
        document.getElementById('ManagerSubpage').style.display = 'none';
        const quitButton = document.getElementById('quitGroup');
        quitButton.textContent = '退出群聊';
        quitButton.className = 'button kick-button'; // 应用样式
        quitButton.onclick = function () {
            quitGroup(userInfo.id);
        };
    } else {
        document.getElementById('MemberSubpage').style.display = 'none';
        document.getElementById('ManagerSubpage').style.display = 'block';
        getGroupInfo();

    }
}

function showGroupInfo() {
    const container = document.getElementById('ManagerSubpage');
    container.innerHTML = ''; // 清空旧成员信息
    groupInfo.forEach(function (member) {
        const col = document.createElement('div');
        col.className = 'col';
        const hoverDiv = document.createElement('div');
        hoverDiv.className = 'group-hover';
        const padDiv = document.createElement('div');
        padDiv.className = 'group-pad';
        const title = document.createElement('h2');
        title.textContent = member.username;
        const bgImg = new Image();
        bgImg.src = 'src/upload/' + member.avatar;
        bgImg.className = 'bg-img';

        // 检查是否是当前用户
        if (userInfo.id !== member.id) {
            const kickButton = document.createElement('button');
            kickButton.textContent = '踢出群聊';
            kickButton.className = 'button kick-button'; // 应用样式
            kickButton.onclick = function () {
                kickMember(member.id);
            };
            padDiv.appendChild(kickButton);
        } else {
            const dismissButton = document.createElement('button');
            dismissButton.textContent = '解散群聊';
            dismissButton.className = 'button dismiss-button'; // 应用样式
            dismissButton.onclick = function () {
                dismissGroup();
            };
            padDiv.appendChild(dismissButton);
        }

        padDiv.appendChild(title);
        hoverDiv.appendChild(padDiv);
        col.appendChild(bgImg);
        col.appendChild(hoverDiv);
        container.appendChild(col);
    });
}

function kickMember(id) {
    //localhost:8080/user/removeMember/${id} POST
    fetch(`http://localhost:8080/user/removeMember/${id}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        }
    })
        .then(response => response.json())
        .then(data => {
            if (data.code === 0) {
                alert(data.message);
                //更新groupInfo
                updateGroupInfoAndRefresh(data.data);
                //刷新页面
                document.getElementById('groupContent').style.display = 'block';
                document.getElementById('groupHeader').style.display = 'none';
                //显示小组信息
                showGroupInfo();
            } else {
                alert(data.message);
            }
        })
        .catch((error) => {
            console.error('Error:', error);
        });
}

function dismissGroup() {
    //localhost:8080/user/deleteGroup/${id} POST
    fetch(`http://localhost:8080/user/deleteGroup/${userInfo.groupid}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        }
    })
        .then(response => response.json())
        .then(data => {
            if (data.code === 0) {
                alert(data.message);
                //更新userInfo
                updateUserInfoAndRefresh(data.data);
                //刷新页面
                document.getElementById('groupContent').style.display = 'none';
                document.getElementById('groupHeader').style.display = 'block';
            } else {
                alert(data.message);
            }
        })
        .catch((error) => {
            console.error('Error:', error);
        });
}

function quitGroup(id) {
    //localhost:8080/user/quitGroup/${id} POST
    fetch(`http://localhost:8080/user/quitGroup/${id}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        }
    })
        .then(response => response.json())
        .then(data => {
            if (data.code === 0) {
                alert(data.message);
                //更新userInfo
                updateUserInfoAndRefresh(data.data);
                //刷新页面
                document.getElementById('groupContent').style.display = 'none';
                document.getElementById('groupHeader').style.display = 'block';
            } else {
                alert(data.message);
            }
        })
        .catch((error) => {
            console.error('Error:', error);
        });
}

function getGroupInfo() {

    //localhost:8080/user/loginGroup POST body:{ "groupid": "1", "managerid": "1"}
    fetch(`http://localhost:8080/user/loginGroup`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            "groupid": userInfo.groupid,
            "managerid": userInfo.ismanager
        })
    })
        .then(response => response.json())
        .then(data => {
            if (data.code === 0) {
                //更新groupInfo
                updateGroupInfoAndRefresh(data.data);
                //刷新页面
                document.getElementById('groupContent').style.display = 'block';
                document.getElementById('groupHeader').style.display = 'none';
                //显示小组信息
                showGroupInfo();
            } else {
                alert(data.message);
            }
        })
        .catch((error) => {
            console.error('Error:', error);
        });
}

checkGroup();

document.getElementById('createGroup').addEventListener('click', function () {
        fetch(`http://localhost:8080/user/createGroup/${userInfo.id}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
        })
            .then(response => response.json())
            .then(data => {
                if (data.code === 0) {
                    alert(data.message);
                    //更新userInfo
                    updateUserInfoAndRefresh(data.data);
                    //刷新页面
                    document.getElementById('groupContent').style.display = 'block';
                    document.getElementById('groupHeader').style.display = 'none';
                    //显示小组信息
                    document.getElementById('groupContent').style.display = 'block';
                    document.getElementById('groupHeader').style.display = 'none';
                    checkManager();

                } else {
                    alert(data.message);
                }
            })
            .catch((error) => {
                console.error('Error:', error);
            });
    }
);

document.getElementById('joinGroup').addEventListener('click', function () {
        alert('移步消息页面申请加入小组');
    }
);
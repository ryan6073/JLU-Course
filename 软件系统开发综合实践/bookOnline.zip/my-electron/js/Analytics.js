document.addEventListener('DOMContentLoaded', function () {
    console.log('Analytics page specific JavaScript');
});

function populateTop3(data) {
    var ctx = document.getElementById('top3Chart').getContext('2d');

    var bookNames = data.map(book => book.bookname + `\n(${book.uploader}, ${book.booklink})`);
    var hits = data.map(book => parseInt(book.hits, 10));  // 确保hits是整数类型

    var myChart = new Chart(ctx, {
        type: 'pie', // 使用扇形图
        data: {
            labels: bookNames,
            datasets: [{
                label: 'Top 3 Books Hits',
                data: hits,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function (tooltipItem) {
                            var idx = tooltipItem.dataIndex;
                            var book = data[idx];
                            return book.bookname + ': ' + book.hits + ' hits\n' +
                                'Uploader: ' + book.uploader + '\n' +
                                'Link: ' + book.booklink;
                        }
                    }
                },
                title: {
                    display: true,
                    text: 'Top 3 Books by Hits'  // 添加标题
                }
            }
        }
    });
}


// POST localhost:8080/book/top3
fetch('http://localhost:8080/book/top3', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'}
})
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok.');
        }
        return response.json();
    })
    .then(data => {
        if (data && data.data) {
            populateTop3(data.data);
        } else {
            throw new Error('Invalid data structure from API');
        }
    })
    .catch(error => {
        console.error('Error loading content:', error);
        // Optionally update the UI to reflect the error
    });

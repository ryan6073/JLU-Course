document.querySelectorAll('.theme-colors .color').forEach(colorDiv => {
    colorDiv.addEventListener('click', function () {
        const color = this.getAttribute('data-color');
        // 将选中的颜色保存到localStorage
        localStorage.setItem('buttonColor', color);
        applyButtonColor(color);
    });
});

// 应用按钮颜色的函数
function applyButtonColor(color) {
    if (color === 'default') {
        document.querySelector(':root').style.setProperty('--button-color', 'linear-gradient(to right bottom, rgba(255,255,255,.7), rgba(255,255,255,.5), rgba(255,255,255,.4))');
    } else {
        document.querySelector(':root').style.setProperty('--button-color', `linear-gradient(to right bottom, 
                             rgba(${hexToRgb(color)}, .7), 
                             rgba(${hexToRgb(color)}, .5), 
                             rgba(${hexToRgb(color)}, .4))`);
    }
}

// 在页面加载完成时加载并应用保存的按钮颜色
document.addEventListener('DOMContentLoaded', function () {
    const savedColor = localStorage.getItem('buttonColor') || 'default';
    applyButtonColor(savedColor);
});

// 将十六进制颜色转换为RGB的函数
function hexToRgb(hex) {
    const r = parseInt(hex.slice(1, 3), 16),
        g = parseInt(hex.slice(3, 5), 16),
        b = parseInt(hex.slice(5, 7), 16);
    return `${r}, ${g}, ${b}`;
}

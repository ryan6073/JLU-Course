CREATE TABLESPACE bookdatabase
LOGGING
datafile 'E:\app\86166\oradata\orcl\bookdatabase.dbf'
size 200m
autoextend on
next 50m maxsize 1000m
extent management local;

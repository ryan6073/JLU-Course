function isEmpty(str) {
    if (str == "" || str.trim() == "") {
        return true;
    }
    return false;
}
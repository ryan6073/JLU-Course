function getParams() {
    const bindName = document.querySelector('input[name="bind-name"]').value;
    const bindValue = document.querySelector('input[name="bind-value"]').value;
    return {bindName, bindValue}
}

function post(type, name, value) {
    const body = "type=" + type + "&name=" + name + "&value=" + value;
    fetch('JNDI', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body
    })
        .then(res => res.text())
        .then(res => {
            document.querySelector('.result-text').innerText = res
        })
}

function bind() {
    const {bindName, bindValue} = getParams();
    post('bind', bindName, bindValue)
}

function query() {
    const {bindName, bindValue} = getParams();
    post('query', bindName, bindValue)
}

function rebind() {
    const {bindName, bindValue} = getParams();
    post('rebind', bindName, bindValue)
}

function unbind() {
    const {bindName, bindValue} = getParams();
    post('unbind', bindName, bindValue)
}
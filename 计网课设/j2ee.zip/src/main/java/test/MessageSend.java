package test;

import com.web_demo.controller.JMSProducerRemote;

import javax.naming.Context;
import javax.naming.InitialContext;
import java.util.Properties;

public class MessageSend {
    public static void main(String[] args) {
        try {
            Properties props = new Properties();
            props.put(Context.INITIAL_CONTEXT_FACTORY, "org.wildfly.naming.client.WildFlyInitialContextFactory");
            props.put(Context.PROVIDER_URL, "http-remoting://localhost:8080");
            props.put(Context.SECURITY_PRINCIPAL, "testJNDI");
            props.put(Context.SECURITY_CREDENTIALS, "123456");
            Context context = new InitialContext(props);

            String lookupName = "ejb:/j2ee-1.0-SNAPSHOT/MyJMSProducer!com.web_demo.controller.JMSProducerRemote";
            JMSProducerRemote producer = (JMSProducerRemote) context.lookup(lookupName);

            producer.sendMessages();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

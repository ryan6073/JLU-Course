package test;

import com.web_demo.controller.RemoteBean;
import jakarta.jms.ConnectionFactory;

import javax.naming.Context;
import javax.naming.InitialContext;
import java.util.Properties;

public class JndiClient {
    public static void main(String[] args) {
        try {
            Properties jndiProps = new Properties();
            jndiProps.put(Context.INITIAL_CONTEXT_FACTORY, "org.wildfly.naming.client.WildFlyInitialContextFactory");
            jndiProps.put(Context.PROVIDER_URL, "http-remoting://localhost:8080");
             jndiProps.put(Context.SECURITY_PRINCIPAL, "testJNDI");
             jndiProps.put(Context.SECURITY_CREDENTIALS, "123456");

            Context context = new InitialContext(jndiProps);

            String myString = (String) context.lookup("mystring");
            RemoteBean remoteBean = (RemoteBean) context.lookup("ejb:/j2ee-1.0-SNAPSHOT/RemoteBeanImpl!com.web_demo.controller.RemoteBean");
            System.out.println(remoteBean.getMyString());

            System.out.println(myString);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
package com.web_demo.controller.impl;

import com.web_demo.controller.MulBy2Local;
import jakarta.ejb.LocalBean;
import jakarta.ejb.Stateful;

@Stateful
@LocalBean
public class MulBy2Bean implements MulBy2Local {
    int i = 1;

    public MulBy2Bean() {
        // TODO Auto-generated constructor stub
    }

    @Override
    public int mul(){
        i = i * 2;
        return i;
    }
}

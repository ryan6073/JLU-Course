package com.web_demo.controller.impl;

import com.web_demo.controller.JMSProducerRemote;
import jakarta.annotation.Resource;
import jakarta.ejb.Stateless;
import jakarta.jms.*;

import java.util.Date;
import java.util.logging.Logger;

@Stateless
@JMSDestinationDefinition(
        name = "java:/jms/queue/MyQueue",
        interfaceName = "jakarta.jms.Queue",
        destinationName = "MyQueue"
)
public class MyJMSProducer implements JMSProducerRemote {
    @Resource(lookup = "java:/jms/queue/MyQueue")
    private Destination queue;

    @Resource(lookup = "java:/ConnectionFactory")
    private ConnectionFactory connectionFactory;

    private static final Logger log = Logger.getLogger(MyJMSProducer.class.getName());

    @Override
    public void sendMessages() {
        try (JMSContext context = connectionFactory.createContext()) {
            JMSProducer producer = context.createProducer();
            long startTime = System.currentTimeMillis();
            long endTime = startTime + 6000;  // 1 minute from start
            int messageCount = 0;

            while (System.currentTimeMillis() < endTime) {
                for (int i = 0; i < 10; i++) {
                    String text = "Time: " + new Date() + ", Message Count: " + (++messageCount);
                    TextMessage message = context.createTextMessage(text);
                    producer.send(queue, message);
                    System.out.println("Sent message: " + text);
                    Thread.sleep(100);  // Sleep for 100 milliseconds to maintain 10 messages per second
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.severe("Thread interrupted: " + e.getMessage());
        } catch (Exception e) {
            log.severe("An exception occurred: " + e.getMessage());
            throw new RuntimeException("Failed to send messages due to an unexpected error", e);
        }
    }
}

package com.web_demo.controller;

import javax.ejb.Remote;

@Remote
public interface RemoteBean {
    String getMyString();
    String getHello();
}


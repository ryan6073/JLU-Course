package com.web_demo.controller;

import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/mulBy2Servlet")
public class MulBy2Servlet extends HttpServlet {

    @EJB
    private MulBy2Local mulBy2Bean;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int result = mulBy2Bean.mul();
        response.setContentType("text/html");
        response.getWriter().write("<html><body><h2>The result is: " + result + "</h2></body></html>");
    }
}

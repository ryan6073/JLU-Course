package com.web_demo.controller;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import javax.naming.*;

@WebServlet("/JNDI")
public class JNDIServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // 获取body参数 操作类型、绑定名字、绑定值
        String type = request.getParameter("type");
        String name = request.getParameter("name");
        String value = request.getParameter("value");
        System.out.println("type: " + type + ", name: " + name + ", value: " + value);

        response.setCharacterEncoding("utf-8");
        response.setStatus(200);
        response.setContentType("plain/text");

        // 根据操作类型进行操作
        try {
            switch (type) {
                case "bind":
                    bind(name, value);
                    response.getWriter().write("绑定 " + name + " 到 " + value);
                    break;
                case "query":
                    String queriedValue = query(name);
                    if (queriedValue != null) {
                        response.getWriter().write("绑定 " + name + " 的值是 " + queriedValue);
                    } else {
                        response.getWriter().write("没有找到绑定 " + name);
                    }
                    break;
                case "rebind":
                    rebind(name, value);
                    response.getWriter().write("重新绑定 " + name + " 到 " + value);
                    break;
                case "unbind":
                    unbind(name);
                    response.getWriter().write("取消绑定 " + name);
                    break;
            }
        } catch (Exception e) {
            response.getWriter().write("操作失败 " + e.getMessage());
        }
    }

    // JNDI
    Context ctx = null;

    // 初始化
    @Override
    public void init() {
        try {
            ctx = new InitialContext();
        } catch (NamingException e) {
            throw new RuntimeException(e);
        }
    }

    // 绑定
    private void bind(String name, String value) {
        // 通过JNDI绑定
        try {
            ctx.bind(name, value);
        } catch (NamingException e) {
            throw new RuntimeException(e);
        }

    }

    // 查询
    private String query(String name) {
        // 通过JNDI查询
        try {
            return (String) ctx.lookup(name);
        } catch (NamingException e) {
            return null;
        }
    }

    // 重新绑定
    private void rebind(String name, String value) {
        // 通过JNDI重新绑定
        try {
            ctx.rebind(name, value);
        } catch (NamingException e) {
            throw new RuntimeException(e);
        }
    }

    // 取消绑定
    private void unbind(String name) {
        // 通过JNDI取消绑定
        try {
            ctx.unbind(name);
        } catch (NamingException e) {
            throw new RuntimeException(e);
        }
    }
}

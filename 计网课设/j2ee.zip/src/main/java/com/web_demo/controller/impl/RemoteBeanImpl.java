package com.web_demo.controller.impl;

import com.web_demo.controller.RemoteBean;
import jakarta.ejb.Remote;
import jakarta.ejb.Stateless;

import javax.annotation.Resource;

@Stateless
@Remote(RemoteBean.class)
public class RemoteBeanImpl implements RemoteBean, java.io.Serializable {
    @Resource(name = "mystring")
    private String myString = "Hello, World!";

    @Resource(name = "hello")
    private String hello = "Hello, World!";

    public String getMyString() {
        return myString;
    }

    public String getHello() {
        return hello;
    }
}

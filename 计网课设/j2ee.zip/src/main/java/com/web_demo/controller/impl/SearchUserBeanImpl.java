package com.web_demo.controller.impl;

import com.web_demo.controller.SearchUserBean;
import com.web_demo.entity.User;
import com.web_demo.mapper.UserMapper;
import jakarta.ejb.Remote;
import jakarta.ejb.Stateless;

import java.sql.SQLException;

@Stateless
@Remote(SearchUserBean.class)
public class SearchUserBeanImpl implements SearchUserBean, java.io.Serializable {

    public User[] searchAllUser() throws SQLException {
        UserMapper userMapper = new UserMapper();
        return userMapper.queryAllUser();
    }
}

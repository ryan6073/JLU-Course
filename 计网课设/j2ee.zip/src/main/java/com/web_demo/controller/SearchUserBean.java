package com.web_demo.controller;

import com.web_demo.entity.User;

import javax.ejb.Remote;
import java.sql.SQLException;

@Remote
public interface SearchUserBean {
    User[] searchAllUser() throws SQLException;
}

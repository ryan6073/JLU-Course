package com.web_demo.controller;


import jakarta.ejb.Local;

@Local
public interface MulBy2Local {
    public int mul();
}

package com.web_demo.controller;

import jakarta.annotation.Resource;
import jakarta.annotation.sql.DataSourceDefinition;
import jakarta.servlet.annotation.WebServlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/MessageQueryServlet")
@DataSourceDefinition(
        name = "java:/MySqlDS",
        className = "com.mysql.cj.jdbc.MysqlDataSource",
        url = "jdbc:mysql://ss.kinaz.me:3306/javaee?serverTimezone=UTC&useSSL=false&characterEncoding=UTF-8&allowPublicKeyRetrieval=true",
        user="kina0630",
        password="323xZJQ030701"
)
public class MessageQueryServlet extends HttpServlet {
    @Resource(lookup = "java:/MySqlDS")
    private DataSource dataSource;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String startTime = request.getParameter("startTime");
        String endTime = request.getParameter("endTime");
        response.setContentType("text/html;charset=UTF-8");

        try (PrintWriter out = response.getWriter()) {
            out.println("<h2>Query Results:</h2>");
            displayMessages(startTime, endTime, out);
            out.println("<hr><a href='/'>Back</a>");
        } catch (Exception e) {
            throw new ServletException("Error processing query", e);
        }
    }

    private void displayMessages(String start, String end, PrintWriter out) throws SQLException {
        String query = "SELECT content, timestamp FROM messages WHERE timestamp BETWEEN ? AND ?";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, start);
            ps.setString(2, end);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                out.println("<p>" + rs.getString("timestamp") + ": " + rs.getString("content") + "</p>");
            }
        }
    }
}

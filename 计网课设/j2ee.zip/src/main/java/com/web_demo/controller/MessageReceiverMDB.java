package com.web_demo.controller;

import jakarta.annotation.Resource;
import jakarta.ejb.ActivationConfigProperty;
import jakarta.ejb.MessageDriven;
import jakarta.jms.Message;
import jakarta.jms.MessageListener;
import jakarta.jms.TextMessage;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.util.logging.Logger;

@MessageDriven(activationConfig = {
        @ActivationConfigProperty(propertyName = "destinationLookup", propertyValue = "java:/jms/queue/MyQueue"),
        @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "jakarta.jms.Queue")
})
public class MessageReceiverMDB implements MessageListener {
    private static final Logger log = Logger.getLogger(MessageReceiverMDB.class.getName());

    @Resource(lookup = "java:/MySqlDS")
    private DataSource dataSource;

    public void onMessage(Message message) {
        if (message instanceof TextMessage) {
            try {
                String text = ((TextMessage) message).getText();
                log.info("Received message: " + text);
                saveMessageToDatabase(text);
            } catch (Exception e) {
                log.severe("Failed to process message: " + e.getMessage());
            }
        }
    }

    private void saveMessageToDatabase(String message) {
        // SQL statement to insert both content and the current timestamp
        String sql = "INSERT INTO messages (content, timestamp) VALUES (?, ?)";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, message);
            ps.setTimestamp(2, new Timestamp(System.currentTimeMillis()));  // Set the current timestamp
            ps.executeUpdate();
        } catch (Exception e) {
            log.severe("Failed to save message to database: " + e.getMessage());
        }
    }
}

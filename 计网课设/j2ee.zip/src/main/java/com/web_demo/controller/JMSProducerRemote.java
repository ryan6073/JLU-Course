package com.web_demo.controller;

import jakarta.ejb.Remote;

@Remote
public interface JMSProducerRemote {
    void sendMessages();
}

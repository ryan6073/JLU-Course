package com.web_demo.mapper;

import com.web_demo.entity.User;

/**
 * 用户Mapper
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserMapper extends BaseMapper {
//    public User login(String name, String password) throws SQLException {
//        Connection con = getConnection();
//        String sql = "SELECT * FROM user WHERE name = ? AND password = ?";
//        PreparedStatement ps = con.prepareStatement(sql);
//        ps.setString(1, name);
//        ps.setString(2, password);
//        ResultSet rs = ps.executeQuery();
//        if (rs.next()) {
//            User user = new User();
//            user.setUserName(rs.getString("name"));
//            user.setUserPwd(rs.getString("password"));
//            return user;
//        }
//        return null;
//    }
//
//    public User register(String name, String password) throws SQLException {
//        Connection con = getConnection();
//        String sql = "INSERT INTO user (name, password) VALUES (?, ?)";
//        PreparedStatement ps = con.prepareStatement(sql);
//        ps.setString(1, name);
//        ps.setString(2, password);
//        ps.executeUpdate();
//        return login(name, password);
//    }

    public User queryUserByName(String uname) throws SQLException {
        Connection con = getConnection();
        String sql = "SELECT * FROM user WHERE name = ?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, uname);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            User user = new User();
            user.setUserId(rs.getInt("id"));
            user.setUserName(rs.getString("name"));
            user.setUserPwd(rs.getString("password"));
            return user;
        }
        return null;
    }

    public void insertUser(User u) throws SQLException {
        Connection con = getConnection();
        String sql = "INSERT INTO user (name, password) VALUES (?, ?)";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, u.getUserName());
        ps.setString(2, u.getUserPwd());
        ps.executeUpdate();
    }

    public User[] queryAllUser() throws SQLException {
        Connection con = getConnection();
        String sql = "SELECT * FROM user";
        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        User[] users = new User[100];
        int i = 0;
        while (rs.next()) {
            User user = new User();
            user.setUserId(rs.getInt("id"));
            user.setUserName(rs.getString("name"));
//            user.setUserPwd(rs.getString("password"));
            users[i] = user;
            i++;
        }
        return users;
    }
}

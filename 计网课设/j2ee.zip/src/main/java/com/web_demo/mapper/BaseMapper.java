package com.web_demo.mapper;

import java.sql.*;

public class BaseMapper {
    static private Connection con = null;

    private static final String driver = "com.mysql.cj.jdbc.Driver";
    private static final String DB_URL = "jdbc:mysql://ss.kinaz.me:3306/javaee?serverTimezone=UTC&useSSL=false&characterEncoding=UTF-8&allowPublicKeyRetrieval=true";
    private static final String USER = "kina0630";
    private static final String PASS = "323xZJQ030701";

    static public void init() {
        try {
            Class.forName(driver);
            con = DriverManager.getConnection(
                    DB_URL,
                    USER,
                    PASS);
        } catch (ClassNotFoundException | SQLException e) {
            throw new RuntimeException(e);
        }
    }

    static public void destroy() {
        if (con == null) {
            return;
        }
        try {
            con.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    static synchronized public Connection getConnection() {
        if (con == null) {
            init();
        }
        return con;
    }
}
